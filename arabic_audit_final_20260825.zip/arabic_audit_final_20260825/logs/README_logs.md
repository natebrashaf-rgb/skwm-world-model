# logs/ 目录说明（API 查询与核验日志）

本目录存放 2026-08-20 任务A/B 拉取与核验阶段的运行日志。

## 文件清单

| 文件 | 覆盖阶段 | 运行时间 | 内容 | 原始状态 |
|------|---------|---------|------|---------|
| doaj_fetch_log.txt | DOAJ API 查询 | 2026-08-20 22:35-22:43 | 3 个 ISSN 期刊全量 + 7 个关键词查询；每查询 total 计数、分页超限(400)截断记录、连续失败 5 次跳过重试记录；EXIT=0 | 脚本落盘（原始） |
| openalex_fetch_log.txt | OpenAlex API 查询 | 2026-08-20 22:12 | 6 个查询词（tourism/heritage/travel/hospitality/سياحة/تراث）、cursor 分页 per-page=200、限速与重试逻辑说明；逐页原始日志未落盘，见文件内说明 | 本次生成（如实说明） |
| pdfcheck_log.txt | PDF 可下载性检测 | 2026-08-20 22:55（check_pdf.py，8 线程）+ 23:05（check_pdf_retry.py 抽样验证） | 3457 条逐批进度 + pdf_check 分布统计（ok_pdf 121 / timeout 1850 / no_url 1085 等）；EXIT=0 | 脚本落盘（原始） |
| B1_fulltext_log.txt | 121 条全文核验 | 2026-08-20 23:46（B1_fulltext_verify.py） | 121 条逐批进度 + 六类判定汇总 + 年份分布；EXIT=0 | 脚本落盘（原始） |

## 分页 / 失败 / 重试记录摘要

- DOAJ：关键词 "cultural tourism"、"heritage tourism"、"travel" 在第 11 页遇到 HTTP 400（DOAJ 翻页上限），记录"翻页超限(400)，截断"；连续失败 5 次的期刊被跳过（本次未触发）；每次失败 sleep 3s 后重试。
- OpenAlex：cursor 翻页至无下一页为止；页间 sleep 0.3s；失败 sleep 3s 重试。逐页记录未落盘（详见 openalex_fetch_log.txt）。
- PDF 检测：1850 条 timeout（埃及 ekb.eg 网络阻断，经 check_pdf_retry.py 抽样 50 条验证为网络侧问题而非链接错误）。

## 查询日期
所有查询均发生在 2026-08-20（当天 22:10-23:47 连续完成拉取→去重→语言复核→PDF 检测→全文核验）。
