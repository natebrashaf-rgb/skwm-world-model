# 数据字典（data_dictionary.md）

本包 A/B 终版文件：每个文件、每列的含义。生成时间 2026-08-25。

---

## 1. raw/candidates_openalex.csv（3397 条数据行）

OpenAlex API 拉取的候选文献（2026-08-20 22:12，fetch_openalex.py）。
范围：language:ar + 1995-01-01~2025-12-31 + 6 个文旅主题词（tourism/heritage/travel/hospitality/سياحة/تراث）并集，去重后 3397 条。

| 列名 | 含义 |
|------|------|
| openalex_id | OpenAlex 作品 ID（W 开头） |
| doi | DOI 标识（无则空） |
| title | 题名 |
| year | 出版年份 |
| venue | 期刊/来源名称 |
| issn | ISSN（无则空） |
| language | API 返回的语言字段 |
| pdf_url | OA 全文 PDF 链接（无则空） |
| landing_url | 作品落地页链接 |
| source_db | 来源库标识，全部为 OpenAlex |
| query | 命中的查询词 |

## 2. raw/candidates_doaj.csv（4109 条数据行）

DOAJ API 拉取的候选文献（2026-08-20 22:35-22:43，fetch_doaj.py）。
来源：3 个阿语期刊 ISSN 全量（2537-0510/2682-4329/2314-7024）+ 7 个关键词查询并集，去重后 4109 条。

| 列名 | 含义 |
|------|------|
| doaj_id | DOAJ 文章 ID |
| doi / title / year / venue / issn / language / pdf_url / landing_url | 同 OpenAlex 表 |
| source_db | 来源库标识，全部为 DOAJ |
| query | 命中的查询词（issn:xxx 或 kw:xxx） |

## 3. screening/candidates_merged_deduped.csv（7209 条数据行）

两个原始表合并 + 内部去重 + 与 B1 主表（12,177 条基线）三层去重后的候选集
（2026-08-20 22:40，dedup_and_lang.py）。7506 → 内部去重 7276 → 撞 DOI 52 → 撞题名 15 → 7209。

| 列名 | 含义 |
|------|------|
| openalex_id / doaj_id | 各自 ID（哪个库有就填哪个） |
| doi / title / year / venue / issn / language / pdf_url / landing_url / source_db / query | 同 raw 表 |
| ar_ratio | 题名中阿语字符占比（0-1） |
| fa_ratio | 题名中波斯语字符占比（0-1） |
| pass_A_15 | 是否通过口径A（阿语≥15% 且 波斯≤15%），True/False |
| pass_B_30 | 是否通过口径B（阿语>30%），True/False |

## 4. screening/candidates_passA15_pdfcheck.csv（3457 条数据行）

通过口径A的 3457 条候选 + PDF 可下载性检测结果（2026-08-20 22:55，check_pdf.py，8 线程）。

| 列名 | 含义 |
|------|------|
| 前 16 列 | 同 candidates_merged_deduped.csv |
| pdf_check | PDF 链接检测结果：ok_pdf=能下到真实 PDF（121 条）／timeout=超时（埃及 ekb.eg 网络阻断）／no_url=无链接／blocked=被拦／err:*／ok_other:*／ok_nopdf 等 |

## 5. screening/screening_final.csv（3457 条数据行）

终版主筛选表 = arabic_master_20260821.csv 改名（2026-08-21 12:07，build_master.py）。
候选/全文/案例/排除四种状态统一表，每条带稳定 ID。

| 列名 | 含义 |
|------|------|
| stable_id | 稳定 ID：openalex_id → doi → doaj_id → ARABIC-<年>-<hash>，全表唯一 |
| status | 状态：candidate（候选 3295）/ fulltext（全文核验未入案例 31）/ case_pool（案例池 90）/ excluded（排除 41） |
| exclude_reason | 排除原因（excluded 才有）：<1995（3 条）/ 2026 年（38 条） |
| source_files | 来源文件：candidates_passA15_pdfcheck.csv / B1_fulltext_verification.csv / qual_case_dedup.csv |
| openalex_id … query | 同 raw 表 |
| ar_ratio_title / fa_ratio_title | 题名口径阿语/波斯占比（候选层） |
| pass_A_15 / pass_B_30 | 口径A/B 通过标记 |
| pdf_check | PDF 检测结果 |
| idx_v | 121 或 90 核验表中的序号 |
| category / basis | 全文核验六类判定（AR_PURE/QUAL_CASE/AR_EN_BILING/LANG_MISJUDG/NOT_TOURISM/QUANT_ONLY）+ 判定依据 |
| ar_ratio_body / fa_ratio_body / en_ratio_body | 正文口径阿语/波斯/英语占比（全文层） |
| text_len / pages | 正文长度/页数 |
| tourism_hits / tourism_hit_ratio / hit_keywords | 文旅主题词命中数/占比/命中的词 |
| download_status | 全文下载状态（121 条核验层） |
| authors / author_note | 作者/备注 |
| dup_group / dup_same_theme / merge_suggest / weak_group / dup_author_note | 案例池去重分组信息 |
| include_in_model / model_rule | 是否入模型（1=纯阿语正文+文旅相关+全文可得，共 61）+ 判定规则说明 |
| include_in_case / case_rule | 是否入案例池（1=90 条）+ 判定规则说明 |

## 6. screening/pool_121_fulltext.csv（121 条数据行）

121 条全文池 = candidates_passA15_pdfcheck.csv 中 pdf_check=ok_pdf 的 121 条（本次打包生成，行数与
B1_fulltext_verification.csv 完全一致，对称差 0）。17 列同 candidates_passA15_pdfcheck.csv。

## 7. screening/pool_90_cases.csv（90 条数据行）

90 条案例池 = arabic_case_pool_90.csv 改名（build_master.py 输出，含 include_in_model/include_in_case 标记）。

| 列名 | 含义 |
|------|------|
| stable_id / idx / openalex_id / doi / title / year / venue / source_db | 标识与基本信息 |
| category / basis | 六类判定中的案例类（AR_PURE 61 / QUAL_CASE 24 / AR_EN_BILING 5）+ 依据 |
| ar_ratio_body / fa_ratio_body / en_ratio_body | 正文阿语/波斯/英语占比 |
| text_len / tourism_hits / tourism_hit_ratio / hit_keywords | 正文长度/文旅命中 |
| authors / author_note | 作者/备注（6 条无作者已标注） |
| dup_group / dup_same_theme / merge_suggest / weak_group / dup_author_note | 去重分组信息（weak_group=2 为伊斯兰金融 2 篇，建议人工确认） |
| pdf_url | PDF 链接 |
| include_in_model / model_rule | 入模型标记（61 条为 1） |
| include_in_case / case_rule | 入案例标记（90 条全为 1） |

## 8. screening/pool_27_cd.csv（27 条数据行，本次新导出）

B1 主表（最新版 rail_deploy/data/B1_文献主表.json，12233 条）中 language=ar 的 27 条。
导出脚本 scripts/build_pool27.py。

| 列名 | 含义 |
|------|------|
| idx | 1-27 序号 |
| title | 题名（主表原文） |
| year | 年份（无则空） |
| authors | 作者 |
| venue | 期刊/来源 |
| doi | DOI（部分无） |
| _source | 来源文件夹 |
| language | 主表语言字段（全部 ar） |
| keywords | 关键词（JSON 数组文本） |
| has_pdf | 主表 has_pdf 字段：是否已有 PDF 文件（12 条 True） |
| pdf_texts_match | 阿语文本库匹配状态：matched=在 pdf_texts.json（6063 篇全文库）中找到该篇全文／not_matched=未找到 |
| pdf_texts_key | 匹配到的 pdf_texts.json 键名（未匹配为空） |
| match_method | 匹配方法：doi_key / ar_substr / ar_contain / special_en |

匹配结果：27 条中 17 条 matched（含全部 13 条文旅相关条目），10 条 not_matched（均为教学/书法/伊斯兰文化类，has_pdf 全 False）。

## 9. pdf_manifest.csv（121 条数据行）

121 条全文名单 + 下载状态（来源 B1_fulltext_verification.csv）。

| 列名 | 含义 |
|------|------|
| idx | 1-121 序号 |
| title / doi / year / venue / source_db | 基本信息 |
| pdf_url | PDF 链接 |
| download_status | 全文核验时的下载状态（本次 121 条全部 ok） |
| category | 六类判定（AR_PURE 61 / QUAL_CASE 24 / LANG_MISJUDG 15 / NOT_TOURISM 10 / QUANT_ONLY 6 / AR_EN_BILING 5） |
| ar_ratio | 正文阿语占比 |
| tourism_hits | 文旅主题词命中数 |

## 10. scripts/（全部用到的脚本，可复跑）

| 脚本 | 作用 | 输出 |
|------|------|------|
| fetch_openalex.py | OpenAlex 拉取（6 查询词，cursor 分页） | raw/candidates_openalex.csv |
| fetch_doaj.py | DOAJ 拉取（3 ISSN + 7 关键词） | raw/candidates_doaj.csv |
| dedup_and_lang.py | 合并去重 + 题名语言复核（口径A/B） | candidates_merged_deduped.csv、candidates_passA15.csv、dedup_report.txt、language_report.txt |
| check_pdf.py | 3457 条 PDF 可下载性检测 | candidates_passA15_pdfcheck.csv |
| check_pdf_retry.py | 抽样 50 条验证 timeout=网络阻断 | pdfcheck_log.txt |
| B1_fulltext_verify.py | 121 条全文核验（六类判定） | B1_fulltext_verification.csv |
| dedup_cases.py | 案例池去重分组 | qual_case_dedup.csv |
| fetch_authors.py | 案例作者补充查询 | qual_case_authors.csv |
| build_master.py | 统一主表 + 两个标记 | screening_final.csv、arabic_model_inclusion.csv、pool_90_cases.csv |
| build_snapshot.py | 图库聚合层快照 | graph_snapshot、topic_year_heat |
| build_pool27.py | 导出 pool_27_cd.csv（本次新增） | screening/pool_27_cd.csv |
| funnel_report.py | 四层漏斗统计报告 | funnel_report.txt |

## 11. logs/

见 logs/README_logs.md（查询日期、分页、失败与重试记录）。
