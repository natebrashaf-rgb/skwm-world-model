# -*- coding: utf-8 -*-
"""
案例池回源补作者（2026-08-20）
对 90 条定性案例池：按 openalex_id 或 DOI 回源 OpenAlex 查 authorships（作者名列表）
输出: qual_case_authors.csv（90条 + 作者字段）
规则：查不到的记「待人工」不猜
"""
import csv, os, sys, time, urllib.request, urllib.parse, json, re

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "B1_fulltext_verification.csv")
OUT = os.path.join(HERE, "qual_case_authors.csv")

def oa_fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "skwm-data-audit/1.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read())

def get_authors(oid, doi):
    """按 OpenAlex ID 或 DOI 查 authorships"""
    try:
        if oid:
            url = f"https://api.openalex.org/works/{oid}?select=id,doi,authorships"
            d = oa_fetch(url)
        elif doi:
            url = "https://api.openalex.org/works/https://doi.org/" + urllib.parse.quote(doi) + "?select=id,doi,authorships"
            d = oa_fetch(url)
        else:
            return "", "no_id_no_doi"
        aus = d.get("authorships") or []
        names = [a.get("author", {}).get("display_name", "") for a in aus if a.get("author", {}).get("display_name")]
        raw_org = [a.get("raw_author_name", "") for a in aus if a.get("raw_author_name")]
        if names:
            return " | ".join(names), ""
        if raw_org:
            return " | ".join(raw_org), "raw_only"
        return "", "empty_authors"
    except Exception as e:
        return "", "api_err:" + type(e).__name__

def main():
    rows = list(csv.DictReader(open(SRC, encoding="utf-8-sig")))
    qual = [r for r in rows if r["category"] in ("AR_PURE", "AR_EN_BILING", "QUAL_CASE")]
    print(f"案例池: {len(qual)} 条", flush=True)
    results = []
    for i, r in enumerate(qual):
        authors, note = get_authors(r.get("openalex_id", ""), r.get("doi", ""))
        results.append({**r, "authors": authors, "author_note": note})
        if (i + 1) % 20 == 0:
            print(f"  进度 {i+1}/{len(qual)}", flush=True)
        time.sleep(0.15)
    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        w.writeheader()
        w.writerows(results)
    got = sum(1 for r in results if r["authors"])
    missing = [r for r in results if not r["authors"]]
    print(f"拿到作者: {got} / 缺作者: {len(missing)}")
    for r in missing:
        print(f"  MISSING: {r['title'][:50]} | note={r['author_note']} | oid={r['openalex_id'][:25]} | doi={r['doi'][:30]}")
    print(f"输出: {OUT}")

if __name__ == "__main__":
    main()
