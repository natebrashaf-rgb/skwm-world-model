# -*- coding: utf-8 -*-
"""
任务B 第1步：121 条全文内容核验（2026-08-20）
对 candidates_passA15_pdfcheck.csv 中 pdf_check=ok_pdf 的 121 条：
  1. 实际下载 PDF（3次重试，15s超时）
  2. 提取文本（PyMuPDF，最多前10页）
  3. 逐篇判定六类：
     AR_PURE      纯阿语正文（阿语字符占比>=60% 且英文<20%）
     AR_EN_BILING 阿英双语（阿语>=15% 且英文>=20%）
     LANG_MISJUDG 语言误判（阿语<15%，正文语言与题名/元数据不符）
     NOT_TOURISM  内容非文旅（文旅主题词命中数=0）
     QUAL_CASE    可作定性案例（阿语占比>=15% 且 文旅主题词命中>=1 且文本量充足）
     QUANT_ONLY   只能作数量边界证据（其余：文本不足/提取失败/边缘）
  4. 输出表1：全文核验明细（每条含判定+依据字段）+ 121 条年份分布
标注规则见文件头，可复跑。
"""
import csv, os, sys, time, re, urllib.request, ssl, socket
from collections import Counter

socket.setdefaulttimeout(20)
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "candidates_passA15_pdfcheck.csv")
OUT = os.path.join(HERE, "B1_fulltext_verification.csv")
PDFDIR = os.path.join(HERE, "pdf_downloads")

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE

AR_RE = re.compile(r'[\u0600-\u06FF]')
FA_RE = re.compile(r'[\u067E\u0686\u0698\u06AF]')
EN_RE = re.compile(r'[A-Za-z]')

# 文旅主题词表（中阿英，用于内容非文旅判定）
TOURISM_KEYWORDS = [
    # tourism 旅游
    "tourism", "tourist", "travel", "tour", "hospitality", "hotel",
    "سياحة", "سياحي", "سائح", "السياحية", "السياحة",
    "فندق", "فنادق", "ضيافة", "سفر",
    # heritage 遗产
    "heritage", "cultural", "culture", "museum", "archaeolog", "antiquities",
    "تراث", "ثقافة", "ثقافي", "متحف", "متاحف", "آثار", "أثار", "اثار",
    # tourism-adjacent
    "ecotourism", "sustainable tourism", "destination", "resort",
    "سياحة بيئية", "سياحة مستدامة",
]

def download_pdf(url, dest):
    """下载 PDF，返回 True/False。3 次重试。"""
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                "Accept": "application/pdf,*/*"})
            with urllib.request.urlopen(req, timeout=20, context=CTX) as r:
                data = r.read()
            if len(data) < 1000:
                return False, "too_small"
            with open(dest, "wb") as f:
                f.write(data)
            return True, f"ok_{len(data)}B"
        except Exception as e:
            err = str(e)
            if attempt == 2:
                return False, "dl_err:" + type(e).__name__
            time.sleep(2 * (attempt + 1))
    return False, "unknown"

def extract_text(pdf_path, max_pages=10):
    """提取 PDF 前 max_pages 页文本，返回 (文本, 页数, 错误)"""
    try:
        import fitz
        doc = fitz.open(pdf_path)
        n = min(doc.page_count, max_pages)
        parts = []
        for i in range(n):
            try:
                parts.append(doc[i].get_text("text"))
            except Exception:
                pass
        doc.close()
        text = "\n".join(parts)
        return text, n, ""
    except Exception as e:
        return "", 0, "pdf_err:" + type(e).__name__

def ratios(text):
    if not text:
        return 0.0, 0.0, 0.0, 0
    total = len(text)
    ar = len(AR_RE.findall(text)) / total
    fa = len(FA_RE.findall(text)) / total
    en = len(EN_RE.findall(text)) / total
    return ar, fa, en, len(text)

def classify(r, text, pages, dl_ok):
    """返回 (类别, 依据, 详细指标)"""
    ar, fa, en, tlen = ratios(text)
    meta = {
        "ar_ratio": round(ar, 4), "fa_ratio": round(fa, 4),
        "en_ratio": round(en, 4), "text_len": tlen, "pages": pages,
        "download_ok": dl_ok,
    }
    if not dl_ok:
        return "QUANT_ONLY", "无法下载", meta
    if tlen < 500:
        return "QUANT_ONLY", "文本量不足(<500字符)，只能作数量边界证据", meta
    # 主题命中
    tl = text.lower()
    hits = [kw for kw in TOURISM_KEYWORDS if kw.lower() in tl]
    hit_ratio = len(hits) / len(TOURISM_KEYWORDS)
    meta["tourism_hits"] = len(hits)
    meta["tourism_hit_ratio"] = round(hit_ratio, 4)
    meta["hit_keywords"] = hits[:8]

    if ar < 0.15:
        return "LANG_MISJUDG", f"正文阿语占比{ar:.1%}<15%，语言误判", meta
    if len(hits) == 0:
        return "NOT_TOURISM", f"文旅主题词0命中（阿语占比{ar:.1%}）", meta
    # 语言纯度判定（文旅相关的前提下）
    if ar >= 0.60 and en < 0.20:
        if tlen >= 2000:
            return "AR_PURE", f"纯阿语正文(阿语{ar:.1%}/英文{en:.1%})，文旅词命中{len(hits)}个，文本充足", meta
        return "QUANT_ONLY", f"纯阿语正文但文本仅{tlen}字符，只能作数量边界证据", meta
    if ar >= 0.30 and en >= 0.20:
        if tlen >= 2000:
            return "AR_EN_BILING", f"阿英双语(阿语{ar:.1%}/英文{en:.1%})，文旅词命中{len(hits)}个，文本充足", meta
        return "QUANT_ONLY", f"阿英双语但文本仅{tlen}字符，只能作数量边界证据", meta
    # 边缘：阿语占比中等或文本不足
    if tlen >= 2000 and len(hits) >= 2:
        return "QUAL_CASE", f"阿语占比中等({ar:.1%})但文旅词命中{len(hits)}个且文本充足，可作定性案例", meta
    return "QUANT_ONLY", f"文本仅{tlen}字符/文旅命中{len(hits)}个，只能作数量边界证据", meta

def main():
    os.makedirs(PDFDIR, exist_ok=True)
    rows = list(csv.DictReader(open(SRC, encoding="utf-8-sig")))
    ok = [r for r in rows if r.get("pdf_check") == "ok_pdf"]
    print(f"待核验: {len(ok)} 条", flush=True)

    results = []
    for i, r in enumerate(ok):
        url = r.get("pdf_url", "")
        dest = os.path.join(PDFDIR, f"pdf_{i:03d}.pdf")
        if os.path.exists(dest) and os.path.getsize(dest) > 1000:
            dl_ok, dl_note = True, "cached"
        else:
            dl_ok, dl_note = download_pdf(url, dest)
        text, pages, perr = ("", 0, "no_download") if not dl_ok else extract_text(dest)
        if perr:
            dl_ok, dl_note = False, perr
        cat, basis, meta = classify(r, text, pages, dl_ok)
        results.append({
            "idx": i,
            "openalex_id": r.get("openalex_id", ""),
            "doi": r.get("doi", ""),
            "title": r.get("title", ""),
            "year": r.get("year", ""),
            "venue": r.get("venue", ""),
            "source_db": r.get("source_db", ""),
            "pdf_url": url,
            "download_status": "ok" if dl_ok else "failed:" + dl_note,
            "category": cat,
            "basis": basis,
            **meta,
        })
        if (i + 1) % 20 == 0:
            print(f"  进度 {i+1}/{len(ok)}", flush=True)

    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        fieldnames = ["idx", "openalex_id", "doi", "title", "year", "venue",
                      "source_db", "pdf_url", "download_status", "category", "basis",
                      "ar_ratio", "fa_ratio", "en_ratio", "text_len", "pages",
                      "tourism_hits", "tourism_hit_ratio", "hit_keywords"]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in results:
            w.writerow({k: (r.get(k, "") if k != "hit_keywords" else ";".join(r.get("hit_keywords", []))) for k in fieldnames})

    # 汇总
    cat_cnt = Counter(r["category"] for r in results)
    year_cnt = Counter(r["year"] for r in results)
    dl_fail = sum(1 for r in results if r["download_status"] != "ok")
    print("=== 八分类汇总（六类判定 + 无法下载 + 总）===")
    for c in ["AR_PURE", "AR_EN_BILING", "LANG_MISJUDG", "NOT_TOURISM", "QUAL_CASE", "QUANT_ONLY"]:
        print(f"  {c}: {cat_cnt.get(c, 0)}")
    print(f"  无法下载: {dl_fail}")
    print(f"  合计: {len(results)}")
    print("=== 年份分布（121条）===")
    print("  " + ", ".join(f"{y}:{c}" for y, c in sorted(year_cnt.items())))
    print(f"输出: {OUT}")

if __name__ == "__main__":
    main()
