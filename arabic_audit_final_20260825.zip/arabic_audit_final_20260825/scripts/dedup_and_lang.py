# -*- coding: utf-8 -*-
"""
任务A 第2步：候选与 B1_文献主表.json 三层去重 + 第3步：语言复核（两档）
输入: candidates_openalex.csv + candidates_doaj.csv + data/B1_文献主表.json
流程:
  1. 合并两库候选，按 source_db 计数
  2. 与 B1 去重:
     L1 DOI 精确匹配
     L2 OpenAlex ID 匹配（B1 无此字段，用 DOI 反向：B1 的 DOI 在 OpenAlex 记录里查不到的话不算；实际上 OpenAlex ID 是 OpenAlex 特有的，B1 里没有，所以 L2 用「OpenAlex ID 去重候选内部」+「B1 的 DOI 归一化 vs 候选 DOI」）
     L3 标准化题名（小写去标点）模糊匹配
  3. 语言复核: 题名跑阿语占比，≥15%（口径A）和 >30%（口径B）两档
输出:
  candidates_merged_deduped.csv   — 与 B1 去重后的候选
  dedup_report.txt               — 每层撞掉数
  language_report.txt            — 两档语言复核结果
"""
import csv, json, os, re, sys, unicodedata
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
OA = os.path.join(HERE, "candidates_openalex.csv")
DJ = os.path.join(HERE, "candidates_doaj.csv")
B1 = r"E:\大挑\rail_deploy\data\B1_文献主表.json"
OUT_MERGED = os.path.join(HERE, "candidates_merged_deduped.csv")
OUT_DEDUP = os.path.join(HERE, "dedup_report.txt")
OUT_LANG = os.path.join(HERE, "language_report.txt")

AR_RE = re.compile(r'[\u0600-\u06FF]')
FA_RE = re.compile(r'[\u067E\u0686\u0698\u06AF]')

def norm_doi(d):
    if not d:
        return ""
    d = str(d).strip().lower()
    d = re.sub(r"^https?://(dx\.)?doi\.org/", "", d)
    d = d.rstrip(".")
    return d

def norm_title(t):
    """小写 + 去标点 + 压缩空白 + 去阿拉伯变音符号"""
    if not t:
        return ""
    t = str(t).lower()
    t = unicodedata.normalize("NFKD", t)
    # 去阿拉伯变音符号（harakat）
    t = re.sub(r'[\u064B-\u0652\u0670]', '', t)
    t = re.sub(r'[^\w\u0600-\u06FF]', '', t)
    return t

def ar_ratio(text):
    if not text:
        return 0.0
    t = str(text)
    return len(AR_RE.findall(t)) / len(t) if t else 0.0

def fa_ratio(text):
    if not text:
        return 0.0
    t = str(text)
    return len(FA_RE.findall(t)) / len(t) if t else 0.0

def load_b1(path):
    with open(path, encoding="utf-8") as f:
        raw = f.read()
    # 剥 _wm 水印
    raw = re.sub(r'^\[\s*"_wm"\s*:\s*"[^"]*"\s*,\s*', '[', raw)
    data = json.loads(raw)
    print(f"B1 加载: {len(data)} 条")
    return data

def main():
    # 1. 加载候选
    oa_rows = list(csv.DictReader(open(OA, encoding="utf-8-sig")))
    dj_rows = []
    if os.path.exists(DJ):
        dj_rows = list(csv.DictReader(open(DJ, encoding="utf-8-sig")))
    print(f"OpenAlex 候选: {len(oa_rows)}")
    print(f"DOAJ 候选: {len(dj_rows)}")

    # 候选内部去重：跨库按 DOI → 题名
    internal_seen = {}
    cand = []
    for r in oa_rows + dj_rows:
        doi = norm_doi(r.get("doi", ""))
        key = doi if doi else norm_title(r.get("title", ""))
        if not key:
            continue
        if key in internal_seen:
            # 合并：优先保留有 PDF 的，来源合并
            existing = internal_seen[key]
            if r.get("pdf_url") and not existing.get("pdf_url"):
                existing["pdf_url"] = r["pdf_url"]
            existing["source_db"] = existing["source_db"] + "+" + r["source_db"]
            continue
        r["_key"] = key
        internal_seen[key] = r
        cand.append(r)
    print(f"候选内部去重后: {len(cand)}（原始 {len(oa_rows)+len(dj_rows)}）")

    # 2. 加载 B1
    b1 = load_b1(B1)
    b1_dois = set()
    b1_titles = set()
    for x in b1:
        d = norm_doi(x.get("doi", ""))
        if d:
            b1_dois.add(d)
        t = norm_title(x.get("title", ""))
        if t:
            b1_titles.add(t)
    print(f"B1 有 DOI 的: {len(b1_dois)}，有题名的: {len(b1_titles)}")

    # 3. 分层去重
    report = []
    # L1: DOI
    hit_doi = []
    remain = []
    for r in cand:
        doi = norm_doi(r.get("doi", ""))
        if doi and doi in b1_dois:
            hit_doi.append(r)
        else:
            remain.append(r)
    report.append(f"L1 DOI 撞掉: {len(hit_doi)}（剩余 {len(remain)}）")

    # L2: OpenAlex ID —— B1 没有 OpenAlex ID 字段，L2 用「候选内部按 openalex_id 去重」
    # （B1 的文献可能来自 OpenAlex，但其 DOI 已由 L1 覆盖；L2 只处理候选内部的同 ID 重复）
    oa_id_map = {}
    l2_dup = 0
    remain2 = []
    for r in remain:
        oid = r.get("openalex_id", "")
        if oid:
            if oid in oa_id_map:
                l2_dup += 1
                continue
            oa_id_map[oid] = r
        remain2.append(r)
    report.append(f"L2 OpenAlex ID 去重（候选内部）: {l2_dup}（剩余 {len(remain2)}）")

    # L3: 标准化题名
    hit_title = []
    final = []
    for r in remain2:
        t = norm_title(r.get("title", ""))
        if t and t in b1_titles:
            hit_title.append(r)
        else:
            final.append(r)
    report.append(f"L3 题名撞掉: {len(hit_title)}（最终剩余 {len(final)}）")

    # 4. 语言复核（对最终候选）
    lang_a = lang_b = 0
    fa_mix = 0
    lang_lines = ["语言复核（题名，2026-08-20）",
                  f"候选数: {len(final)}",
                  f"口径A（阿语≥15% 且波斯专属≤15%）: ",
                  f"口径B（阿语>30%）: "]
    a_rows, b_rows = [], []
    for r in final:
        ar = ar_ratio(r.get("title", ""))
        fa = fa_ratio(r.get("title", ""))
        if ar >= 0.15 and fa <= 0.15:
            lang_a += 1
            a_rows.append(r)
        if ar > 0.30:
            lang_b += 1
            b_rows.append(r)
        if fa > 0.15:
            fa_mix += 1
    lang_lines[2] += str(lang_a)
    lang_lines[3] += str(lang_b)
    lang_lines.append(f"波斯混入（FA>15%）: {fa_mix}")

    # 写 merged 文件（带语言标记）
    with open(OUT_MERGED, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=[
            "openalex_id", "doaj_id", "doi", "title", "year", "venue", "issn",
            "language", "pdf_url", "landing_url", "source_db", "query",
            "ar_ratio", "fa_ratio", "pass_A_15", "pass_B_30"])
        w.writeheader()
        for r in final:
            ar = ar_ratio(r.get("title", ""))
            fa = fa_ratio(r.get("title", ""))
            w.writerow({
                "openalex_id": r.get("openalex_id", ""),
                "doaj_id": r.get("doaj_id", ""),
                "doi": r.get("doi", ""),
                "title": r.get("title", ""),
                "year": r.get("year", ""),
                "venue": r.get("venue", ""),
                "issn": r.get("issn", ""),
                "language": r.get("language", ""),
                "pdf_url": r.get("pdf_url", ""),
                "landing_url": r.get("landing_url", ""),
                "source_db": r.get("source_db", ""),
                "query": r.get("query", ""),
                "ar_ratio": f"{ar:.4f}",
                "fa_ratio": f"{fa:.4f}",
                "pass_A_15": ar >= 0.15 and fa <= 0.15,
                "pass_B_30": ar > 0.30,
            })

    with open(OUT_DEDUP, "w", encoding="utf-8") as f:
        f.write("三层去重报告（2026-08-20）\n")
        f.write(f"候选合并后（内部去重）: {len(cand)}\n")
        for line in report:
            f.write(line + "\n")
        f.write(f"最终剩余（未在 B1 中）: {len(final)}\n")

    with open(OUT_LANG, "w", encoding="utf-8") as f:
        f.write("\n".join(lang_lines) + "\n")

    print("=== 去重报告 ===")
    for line in report:
        print(line)
    print(f"最终剩余: {len(final)}")
    print("=== 语言复核 ===")
    for line in lang_lines:
        print(line)
    print(f"输出: {OUT_MERGED} / {OUT_DEDUP} / {OUT_LANG}")

if __name__ == "__main__":
    main()
