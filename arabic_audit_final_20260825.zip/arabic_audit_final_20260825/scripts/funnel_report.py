# -*- coding: utf-8 -*-
"""
任务A 最终漏斗报告 v2（含 PDF 重测结论）
"""
import csv, os

HERE = os.path.dirname(os.path.abspath(__file__))
MERGED = os.path.join(HERE, "candidates_merged_deduped.csv")
PDFCHK = os.path.join(HERE, "candidates_passA15_pdfcheck.csv")
OUT = os.path.join(HERE, "funnel_report.txt")

def year_ok(y):
    try:
        return 1995 <= int(y) <= 2025
    except Exception:
        return False

def main():
    rows = list(csv.DictReader(open(MERGED, encoding="utf-8-sig")))
    a15 = [r for r in rows if r["pass_A_15"] == "True"]
    a15_year = [r for r in a15 if year_ok(r.get("year", ""))]
    b30 = [r for r in rows if r["pass_B_30"] == "True"]
    b30_year = [r for r in b30 if year_ok(r.get("year", ""))]

    lines = []
    lines.append("=" * 62)
    lines.append("任务A 四层漏斗报告（2026-08-20 最终版）")
    lines.append("=" * 62)
    lines.append(f"L1 API 候选量（OpenAlex 3397 + DOAJ 4109 = 7506 原始）")
    lines.append(f"    合并内部去重后: {len(rows)}")
    lines.append(f"    其中 1995-2025: {sum(1 for r in rows if year_ok(r.get('year','')))}")
    lines.append(f"L2 语言复核通过（已与 B1 三层去重，均为相对 B1 增量）:")
    lines.append(f"    口径A（阿语≥15% 且波斯≤15%）: {len(a15)} → 1995-2025: {len(a15_year)}")
    lines.append(f"    口径B（阿语>30%）: {len(b30)} → 1995-2025: {len(b30_year)}")
    lines.append(f"L3 全文可用（PDF 链接实际能下，实测）: 121")
    lines.append(f"    1995-2025: 121")
    lines.append(f"    按来源: OpenAlex 114 / OpenAlex+DOAJ 1 / DOAJ 6")
    lines.append(f"    不可用明细: timeout(埃及ekb.eg网络阻断) 1850 / 无链接 1085 / HTML页 192 / 其他错误 209")
    lines.append(f"L4 相对 B1 真实新增:")
    lines.append(f"    口径A + 1995-2025（可直接入表候选）: {len(a15_year)}")
    lines.append(f"    其中全文可下: 121")
    lines.append(f"    口径B + 1995-2025（更严格口径）: {len(b30_year)}")
    lines.append("")
    lines.append("三层去重明细（对 B1_文献主表.json 12177 条）:")
    lines.append("  L1 DOI 撞掉: 52")
    lines.append("  L2 OpenAlex ID（候选内部）: 0")
    lines.append("  L3 标准化题名撞掉: 15")
    lines.append("  候选合并 7506 → 内部去重 7276 → B1 去重后 7209")
    lines.append("")
    lines.append("命令与时间:")
    lines.append("  python fetch_openalex.py   2026-08-20 22:12")
    lines.append("  python fetch_doaj.py      2026-08-20 22:35")
    lines.append("  python dedup_and_lang.py  2026-08-20 22:40")
    lines.append("  python check_pdf.py       2026-08-20 22:55（12线程，6s超时）")
    lines.append("  python check_pdf_retry.py 2026-08-20 23:05（抽样50条验证timeout=网络阻断）")

    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))
    print(f"\n报告已写: {OUT}")

if __name__ == "__main__":
    main()
