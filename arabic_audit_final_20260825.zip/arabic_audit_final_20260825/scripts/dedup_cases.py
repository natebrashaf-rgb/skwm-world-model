# -*- coding: utf-8 -*-
"""
案例池去重分析（2026-08-20，任务C/D 输入）
对 90 条定性案例池（qual_case_authors.csv）：
  1. 按 第一作者 × 期刊 分组 → 同作者同刊多篇 = 强重复组
  2. 组内再按 主题关键词重叠 判断是否同主题
  3. 标记：
     dup_group   组号（同一作者+同一期刊）
     dup_same_theme  组内是否同主题（主题关键词交集>=1 或题名相似）
     merge_suggest  合并口径建议（保留哪篇/如何合并），不擅自删
  4. 输出: qual_case_dedup.csv（90条 + 去重标记字段）
合并口径建议规则（写文件头，不执行删除）：
  A. 同作者+同期刊+同主题 → 合并为 1 个案例，保留文本最长/阿语占比最高/文旅词命中最多的一篇
  B. 同作者+同期刊+不同主题 → 各自独立，不合并
  C. 同作者+不同期刊 → 独立
  D. 无作者（待人工）→ 不参与分组，标待人工
"""
import csv, os, re
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "qual_case_authors.csv")
OUT = os.path.join(HERE, "qual_case_dedup.csv")

# 主题关键词（从题名提取主题信号）
THEME_WORDS = [
    "سياحة", "سياحي", "السياحة", "سياحية", "سائح", "فندق", "فنادق", "ضيافة", "سفر",  # 旅游
    "تراث", "تراثي", "ثقافة", "ثقافي", "متحف", "متاحف", "آثار", "اثار", "أثار", "أثر",  # 遗产
    "tourism", "tourist", "travel", "heritage", "cultural", "culture", "museum", "archaeolog",  # 英文
    "إعمار", "عمارة", "بناء", "مباني", "عمران",  # 建筑
    "تخطيط", "تنمية", "تطوير", "استدامة",  # 发展/规划
    "تسويق", "إعلان", "ترويج",  # 营销
    "ضيوف", "زوار", "زيارة",  # 游客
    "حلال", "مزارات", "دينية", "زيارات",  # 宗教旅游
    "اقتصاد", "مالية", "استثمار",  # 经济
]

def first_author(authors):
    if not authors:
        return ""
    return authors.split(" | ")[0].strip()

def theme_set(title):
    t = (title or "").lower()
    hits = set()
    for w in THEME_WORDS:
        if w.lower() in t:
            hits.add(w)
    return hits

def main():
    rows = list(csv.DictReader(open(SRC, encoding="utf-8-sig")))
    print(f"案例池: {len(rows)} 条", flush=True)

    # 计算主题
    for r in rows:
        r["_theme"] = theme_set(r.get("title", ""))
        r["_author"] = first_author(r.get("authors", ""))

    # 分组：第一作者 × 期刊（强重复组）
    groups = defaultdict(list)
    for i, r in enumerate(rows):
        key = (r["_author"], r.get("venue", ""))
        if r["_author"]:  # 无作者不分组
            groups[key].append(i)

    dup_groups = {k: v for k, v in groups.items() if len(v) >= 2}
    print(f"同作者+同期刊 组数: {len(dup_groups)}", flush=True)

    # 第二层：任意作者多篇（不限期刊/不限作者位置）—— 弱重复信号
    # 构建：作者 -> 涉及的文章 idx 集合
    author_to_idx = defaultdict(set)
    for i, r in enumerate(rows):
        for a in (r.get("authors") or "").split(" | "):
            a = a.strip()
            if a:
                author_to_idx[a].add(i)
    # 有作者的文章 idx 按共享作者并集归组
    shared = defaultdict(set)  # 作者 -> 组号
    weak_groups = {}           # 组号 -> idx set
    wid = 0
    for a, idxs in author_to_idx.items():
        if len(idxs) >= 2:
            existing = None
            for gid, gidx in weak_groups.items():
                if idxs & gidx:
                    existing = gid
                    break
            if existing is None:
                wid += 1
                weak_groups[str(wid)] = set(idxs)
            else:
                weak_groups[existing] |= idxs
    print(f"同作者多篇(任意位置) 组数: {len(weak_groups)}", flush=True)

    # 标记
    for r in rows:
        r["dup_group"] = ""
        r["dup_same_theme"] = ""
        r["merge_suggest"] = ""
        r["dup_author_note"] = ""
        r["weak_group"] = ""

    for gid, (key, idxs) in enumerate(dup_groups.items(), 1):
        author, venue = key
        # 组内主题判断
        themes = [rows[i]["_theme"] for i in idxs]
        pair_same = []
        for a in range(len(idxs)):
            for b in range(a + 1, len(idxs)):
                inter = themes[a] & themes[b]
                if inter:
                    pair_same.append((idxs[a], idxs[b], inter))
        for i in idxs:
            rows[i]["dup_group"] = str(gid)
            rows[i]["dup_author_note"] = f"同作者+同期刊组#{gid}（{author} × {venue[:25]}）共{len(idxs)}篇"
        if pair_same:
            for a, b, inter in pair_same:
                rows[a]["dup_same_theme"] = "是"
                rows[b]["dup_same_theme"] = "是"
                # 合并建议：保留指标最优的
                for i in (a, b):
                    if not rows[i]["merge_suggest"]:
                        rows[i]["merge_suggest"] = f"组#{gid}同主题(交集:{','.join(list(inter)[:4])})建议合并为1案例"
        for i in idxs:
            if not rows[i]["merge_suggest"]:
                rows[i]["merge_suggest"] = f"组#{gid}不同主题，各自独立不合并"

    # 弱重复组标记（同作者多篇，任意位置）
    for wid, idxs in weak_groups.items():
        for i in idxs:
            rows[i]["weak_group"] = str(wid)
            if not rows[i]["dup_author_note"]:
                rows[i]["dup_author_note"] = f"同作者{len(idxs)}篇(不限期刊)组#{wid}"

    # 无作者
    for r in rows:
        if not r["_author"]:
            r["dup_author_note"] = "无作者（待人工）"

    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        fieldnames = ["idx", "openalex_id", "doi", "title", "year", "venue", "source_db",
                      "category", "basis", "ar_ratio", "en_ratio", "text_len", "tourism_hits",
                      "authors", "author_note", "dup_group", "dup_same_theme", "merge_suggest",
                      "weak_group", "dup_author_note",
                      "pdf_url"]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fieldnames})

    # 汇总
    gcount = defaultdict(int)
    for r in rows:
        if r["dup_group"]:
            gcount[r["dup_group"]] += 1
    same_theme_pairs = sum(1 for r in rows if r["dup_same_theme"] == "是")
    weak_count = len({r["weak_group"] for r in rows if r["weak_group"]})
    print("=== 去重汇总 ===")
    print(f"90 条中参与强分组: {sum(1 for r in rows if r['dup_group'])}（{len(dup_groups)} 个重复组）")
    print(f"同主题重复标记条数: {same_theme_pairs}")
    print(f"弱分组(同作者多篇)条数: {sum(1 for r in rows if r['weak_group'])}（{weak_count} 组）")
    print(f"无作者待人工: {sum(1 for r in rows if not r['_author'])}")
    print("组明细:")
    for gid in sorted(gcount, key=lambda x: -gcount[x]):
        members = [r for r in rows if r["dup_group"] == gid]
        themes = set()
        for m in members:
            themes |= m["_theme"]
        print(f"  组#{gid} ({len(members)}篇) 主题信号:{','.join(sorted(themes)[:6])}")
        for m in members:
            print(f"    - [{m['category']}] {m['title'][:45]} | {m['year']} | 同主题={m['dup_same_theme']}")
    print("弱分组明细:")
    for wid in sorted({r["weak_group"] for r in rows if r["weak_group"]}, key=lambda x: int(x)):
        members = [r for r in rows if r["weak_group"] == wid]
        print(f"  弱组#{wid} ({len(members)}篇):")
        for m in members:
            print(f"    - [{m['category']}] {m['year']} | {m['venue'][:25]} | {m['title'][:40]}")
    print(f"输出: {OUT}")

if __name__ == "__main__":
    main()
