# -*- coding: utf-8 -*-
"""
A/B 收尾（2026-08-21）：主 CSV + 模型/案例标记
=============================================
输入（均来自 2026-08-20 任务A/B 产出，E:\大挑\产出\manus_reference_20260820\）:
  candidates_passA15_pdfcheck.csv  3457 条语言复核通过候选（含 pdf_check）
  B1_fulltext_verification.csv     121 条全文核验明细（表1）
  qual_case_dedup.csv              90 条定性案例池（含去重标记）
输出（E:\大挑\产出\交接_20260821\）:
  arabic_master_20260821.csv       主 CSV（3457 行，四种状态可追溯）
  arabic_model_inclusion.csv       121 条全文核验 + include_in_model/include_in_case
  arabic_case_pool_90.csv          90 条案例池 + include_in_model/include_in_case

状态规则:
  case_pool   在 90 案例池内
  fulltext    有全文核验但未进案例池（LANG_MISJUDG/NOT_TOURISM/QUANT_ONLY）
  candidate   候选层（语言复核通过，未做全文核验）
  excluded    年份超出 1995-2025 口径（<1995 或 >2025）

include_in_model 规则（防止波斯/土耳其语误判混进模型）:
  1 仅当: 纯阿语正文(category=AR_PURE: 正文阿语>=60% 且英文<20% 且波斯=0)
          + 文旅相关(tourism_hits>=1) + 全文可得(download_status=ok)
  0: 未核验全文 / 语言误判 / 非文旅 / 仅数量证据 / 双语 / 定性但非纯阿语

include_in_case 规则:
  1 = 90 案例池（qual_case_dedup.csv 内）
  0 = 其余

稳定 ID 规则: openalex_id → doi → doaj_id → ARABIC-<year>-<md5(title)前8>
join 规则: 121/90 与候选按 pdf_url → openalex_id → doi 三级对齐
"""
import csv, hashlib, os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = r"E:\大挑\产出\manus_reference_20260820"
OUT = HERE

def stable_id(row):
    for k in ("openalex_id", "doi", "doaj_id"):
        v = (row.get(k) or "").strip()
        if v:
            return v
    y = row.get("year") or "0"
    h = hashlib.md5((row.get("title") or "").encode("utf-8")).hexdigest()[:8]
    return f"ARABIC-{y}-{h}"

def norm(x):
    return (x or "").strip().lower()

# 1. 加载候选
cand = list(csv.DictReader(open(os.path.join(SRC, "candidates_passA15_pdfcheck.csv"), encoding="utf-8-sig")))
v121 = list(csv.DictReader(open(os.path.join(SRC, "B1_fulltext_verification.csv"), encoding="utf-8-sig")))
q90 = list(csv.DictReader(open(os.path.join(SRC, "qual_case_dedup.csv"), encoding="utf-8-sig")))
print(f"加载: 候选 {len(cand)} | 全文 {len(v121)} | 案例 {len(q90)}")

# 2. join 索引（pdf_url → openalex_id → doi 三级）
cand_idx = {}          # pdf_url 规范化 → 候选行
cand_oa = {}           # openalex_id → 候选行
cand_doi = {}          # doi → 候选行
for i, r in enumerate(cand):
    cand_idx.setdefault(norm(r.get("pdf_url")), i)
    if r.get("openalex_id"):
        cand_oa.setdefault(norm(r.get("openalex_id")), i)
    if r.get("doi"):
        cand_doi.setdefault(norm(r.get("doi")), i)

def find_cand(row):
    """返回候选行索引，None 表示未找到"""
    for key in ("pdf_url", "openalex_id", "doi"):
        v = norm(row.get(key))
        if not v:
            continue
        if key == "pdf_url" and v in cand_idx:
            return cand_idx[v]
        if key == "openalex_id" and v in cand_oa:
            return cand_oa[v]
        if key == "doi" and v in cand_doi:
            return cand_doi[v]
    return None

# 3. join 121 和 90
v_pos = {}   # 121 行 → 候选行号
v_join_method = {}
for r in v121:
    i = find_cand(r)
    v_pos[id(r)] = i
    m = "pdf_url" if norm(r.get("pdf_url")) in cand_idx else ("openalex_id" if norm(r.get("openalex_id")) in cand_oa else ("doi" if norm(r.get("doi")) in cand_doi else "NONE"))
    v_join_method[id(r)] = m
n_v = sum(1 for i in v_pos.values() if i is not None)
print(f"121 join 候选: {n_v}/121 (方法: {__import__('collections').Counter(v_join_method.values())})")

q_pos = {}
q_join_method = {}
for r in q90:
    i = find_cand(r)
    q_pos[id(r)] = i
    m = "pdf_url" if norm(r.get("pdf_url")) in cand_idx else ("openalex_id" if norm(r.get("openalex_id")) in cand_oa else ("doi" if norm(r.get("doi")) in cand_doi else "NONE"))
    q_join_method[id(r)] = m
n_q = sum(1 for i in q_pos.values() if i is not None)
print(f"90 join 候选: {n_q}/90 (方法: {__import__('collections').Counter(q_join_method.values())})")
assert n_v == 121 and n_q == 90, "join 失败，先排查"

# 4. 建立 候选行号 → 121/90 信息
v_by_pos = {v_pos[id(r)]: r for r in v121 if v_pos[id(r)] is not None}
q_by_pos = {q_pos[id(r)]: r for r in q90 if q_pos[id(r)] is not None}

# 5. 主 CSV 输出
FIELDS = [
    "stable_id", "status", "exclude_reason", "source_files",
    "openalex_id", "doaj_id", "doi", "title", "year", "venue", "issn",
    "language", "pdf_url", "landing_url", "source_db", "query",
    "ar_ratio_title", "fa_ratio_title", "pass_A_15", "pass_B_30", "pdf_check",
    "idx_v", "category", "basis", "ar_ratio_body", "fa_ratio_body", "en_ratio_body",
    "text_len", "pages", "tourism_hits", "tourism_hit_ratio", "hit_keywords", "download_status",
    "authors", "author_note", "dup_group", "dup_same_theme", "merge_suggest", "weak_group", "dup_author_note",
    "include_in_model", "model_rule", "include_in_case", "case_rule",
]

def model_rule_for(cat):
    if cat == "AR_PURE":
        return "纯阿语正文(正文阿语>=60%/英文<20%/波斯=0)+文旅相关(tourism_hits>=1)+全文可得"
    if cat == "AR_EN_BILING":
        return "阿英双语正文，非纯阿语，不满足'纯阿语正文'条件"
    if cat == "LANG_MISJUDG":
        return "语言误判(正文阿语<15%，如波斯语/土耳其语标题混入)，排除出模型"
    if cat == "NOT_TOURISM":
        return "内容非文旅(文旅主题词0命中)"
    if cat == "QUANT_ONLY":
        return "仅数量边界证据(文本不足/提取失败)"
    return ""

def main():
    os.makedirs(OUT, exist_ok=True)
    rows_out = []
    cnt = {"case_pool": 0, "fulltext": 0, "candidate": 0, "excluded": 0}
    for ci, c in enumerate(cand):
        year = int(c.get("year") or 0)
        # 状态
        if ci in q_by_pos:
            status = "case_pool"
        elif ci in v_by_pos:
            status = "fulltext"
        elif 1995 <= year <= 2025:
            status = "candidate"
        else:
            status = "excluded"
        cnt[status] += 1
        exclude_reason = ""
        if status == "excluded":
            exclude_reason = f"年份{year}超出1995-2025口径" + ("(<1995)" if year < 1995 else "(>2025)")

        src = ["candidates_passA15_pdfcheck.csv"]
        row = dict(c)
        # 全文层
        v = v_by_pos.get(ci)
        if v:
            src.append("B1_fulltext_verification.csv")
            row["idx_v"] = v.get("idx")
            row["category"] = v.get("category")
            row["basis"] = v.get("basis")
            row["ar_ratio_body"] = v.get("ar_ratio")
            row["fa_ratio_body"] = v.get("fa_ratio")
            row["en_ratio_body"] = v.get("en_ratio")
            row["text_len"] = v.get("text_len")
            row["pages"] = v.get("pages")
            row["tourism_hits"] = v.get("tourism_hits")
            row["tourism_hit_ratio"] = v.get("tourism_hit_ratio")
            row["hit_keywords"] = v.get("hit_keywords")
            row["download_status"] = v.get("download_status")
        # 案例层
        q = q_by_pos.get(ci)
        if q:
            src.append("qual_case_dedup.csv")
            for k in ("authors", "author_note", "dup_group", "dup_same_theme",
                      "merge_suggest", "weak_group", "dup_author_note"):
                row[k] = q.get(k)
        # 标记
        cat = row.get("category", "")
        if status == "excluded":
            row["include_in_model"] = "0"
            row["model_rule"] = "年份超出1995-2025口径，不参与模型"
        elif not cat:
            row["include_in_model"] = "0"
            row["model_rule"] = "未核验全文(候选层)，不能确认纯阿语正文，不给"
        elif cat == "AR_PURE":
            row["include_in_model"] = "1"
            row["model_rule"] = model_rule_for("AR_PURE")
        else:
            row["include_in_model"] = "0"
            row["model_rule"] = model_rule_for(cat)
        row["include_in_case"] = "1" if status == "case_pool" else "0"
        row["case_rule"] = "在90案例池内(qual_case_dedup.csv)" if status == "case_pool" else "未进90案例池"

        # 重命名标题占比字段（候选层=标题，全文层=正文，语义区分）
        row["ar_ratio_title"] = row.pop("ar_ratio", "")
        row["fa_ratio_title"] = row.pop("fa_ratio", "")

        out = {k: row.get(k, "") for k in FIELDS}
        out["stable_id"] = stable_id(row)
        out["status"] = status
        out["exclude_reason"] = exclude_reason
        out["source_files"] = ";".join(src)
        rows_out.append(out)

    # 写主 CSV
    p_master = os.path.join(OUT, "arabic_master_20260821.csv")
    with open(p_master, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows_out)
    print(f"主 CSV 写入: {p_master}  行数 {len(rows_out)}")
    print("状态分布:", cnt)
    print("include_in_model=1:", sum(1 for r in rows_out if r['include_in_model'] == '1'),
          "| include_in_case=1:", sum(1 for r in rows_out if r['include_in_case'] == '1'))

    # 6. arabic_model_inclusion.csv（121 全文核验全量）
    F_INC = [
        "stable_id", "idx", "openalex_id", "doi", "title", "year", "venue",
        "source_db", "pdf_url", "download_status", "category", "basis",
        "ar_ratio_body", "fa_ratio_body", "en_ratio_body", "text_len", "pages",
        "tourism_hits", "tourism_hit_ratio", "hit_keywords",
        "include_in_model", "model_rule", "include_in_case", "case_rule",
    ]
    inc_rows = []
    for v in v121:
        ci = v_pos[id(v)]
        c = cand[ci]
        cat = v.get("category")
        o = {
            "stable_id": stable_id(v),
            "idx": v.get("idx"),
            "openalex_id": v.get("openalex_id"),
            "doi": v.get("doi"),
            "title": v.get("title"),
            "year": v.get("year"),
            "venue": v.get("venue"),
            "source_db": v.get("source_db"),
            "pdf_url": v.get("pdf_url"),
            "download_status": v.get("download_status"),
            "category": cat,
            "basis": v.get("basis"),
            "ar_ratio_body": v.get("ar_ratio"),
            "fa_ratio_body": v.get("fa_ratio"),
            "en_ratio_body": v.get("en_ratio"),
            "text_len": v.get("text_len"),
            "pages": v.get("pages"),
            "tourism_hits": v.get("tourism_hits"),
            "tourism_hit_ratio": v.get("tourism_hit_ratio"),
            "hit_keywords": v.get("hit_keywords"),
            "include_in_model": "1" if cat == "AR_PURE" else "0",
            "model_rule": model_rule_for(cat),
            "include_in_case": "1" if ci in q_by_pos else "0",
            "case_rule": "在90案例池内" if ci in q_by_pos else "未进90案例池",
        }
        inc_rows.append(o)
    p_inc = os.path.join(OUT, "arabic_model_inclusion.csv")
    with open(p_inc, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=F_INC)
        w.writeheader()
        w.writerows(inc_rows)
    print(f"model_inclusion 写入: {p_inc}  行数 {len(inc_rows)} | model=1:", sum(1 for r in inc_rows if r['include_in_model'] == '1'))

    # 7. arabic_case_pool_90.csv（90 案例池）
    F_CASE = [
        "stable_id", "idx", "openalex_id", "doi", "title", "year", "venue",
        "source_db", "category", "basis", "ar_ratio_body", "fa_ratio_body", "en_ratio_body",
        "text_len", "tourism_hits", "tourism_hit_ratio", "hit_keywords",
        "authors", "author_note", "dup_group", "dup_same_theme", "merge_suggest",
        "weak_group", "dup_author_note", "pdf_url",
        "include_in_model", "model_rule", "include_in_case", "case_rule",
    ]
    case_rows = []
    for q in q90:
        ci = q_pos[id(q)]
        v = v_by_pos.get(ci)
        cat = v.get("category") if v else ""
        o = {
            "stable_id": stable_id(q),
            "idx": q.get("idx"),
            "openalex_id": q.get("openalex_id"),
            "doi": q.get("doi"),
            "title": q.get("title"),
            "year": q.get("year"),
            "venue": q.get("venue"),
            "source_db": q.get("source_db"),
            "category": q.get("category"),
            "basis": q.get("basis"),
            "ar_ratio_body": q.get("ar_ratio"),
            "fa_ratio_body": v.get("fa_ratio") if v else "",
            "en_ratio_body": q.get("en_ratio"),
            "text_len": q.get("text_len"),
            "tourism_hits": q.get("tourism_hits"),
            "tourism_hit_ratio": q.get("tourism_hit_ratio"),
            "hit_keywords": q.get("hit_keywords"),
            "authors": q.get("authors"),
            "author_note": q.get("author_note"),
            "dup_group": q.get("dup_group"),
            "dup_same_theme": q.get("dup_same_theme"),
            "merge_suggest": q.get("merge_suggest"),
            "weak_group": q.get("weak_group"),
            "dup_author_note": q.get("dup_author_note"),
            "pdf_url": q.get("pdf_url"),
            "include_in_model": "1" if cat == "AR_PURE" else "0",
            "model_rule": model_rule_for(cat),
            "include_in_case": "1",
            "case_rule": "在90案例池内(qual_case_dedup.csv)",
        }
        case_rows.append(o)
    p_case = os.path.join(OUT, "arabic_case_pool_90.csv")
    with open(p_case, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=F_CASE)
        w.writeheader()
        w.writerows(case_rows)
    print(f"case_pool_90 写入: {p_case}  行数 {len(case_rows)} | model=1:", sum(1 for r in case_rows if r['include_in_model'] == '1'))

if __name__ == "__main__":
    main()
