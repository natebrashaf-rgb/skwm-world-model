# -*- coding: utf-8 -*-
"""
任务B 第2步：元数据层分层抽样 200 条（2026-08-20）
从 3416（口径A·1995-2025，已与 B1 去重）按 来源库×年份 分层抽 200 条。
只基于元数据（题名/期刊/ISSN/来源库）判定：
  TOURISM_RELATED  文旅相关（题名/期刊命中文旅关键词，明确）
  UNRELATED        无关（无任何文旅信号）
  DOUBTFUL         存疑（信号弱/无法判断）
并标注语言复核档位（口径A/B）。
分层规则：
  - 来源库层：OpenAlex / DOAJ / OpenAlex+DOAJ 三组
  - 年份层：按 5 年桶 1995-1999/2000-2004/.../2025 加权随机
  - 组内按比例取整，总数固定 200
输出：B2_metadata_sample.csv（含判定依据字段）
标注规则见文件头，可复跑（固定随机种子）。
"""
import csv, os, sys, re, random
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "candidates_merged_deduped.csv")
OUT = os.path.join(HERE, "B2_metadata_sample.csv")
SEED = 20260820

# 文旅关键词（题名匹配用，中阿英）
TITLE_TOURISM_KW = [
    "tourism", "tourist", "travel", "tour", "hospitality", "hotel", "resort", "destination",
    "heritage", "cultural", "culture", "museum", "archaeolog", "antiquities",
    "سياحة", "سياحي", "سائح", "السياحة", "السياحية", "فندق", "فنادق", "ضيافة", "سفر",
    "تراث", "ثقافة", "ثقافي", "متحف", "متاحف", "آثار", "اثار", "أثار",
    "ecotourism", "overtourism", "sustainable tourism",
]
VENUE_TOURISM_KW = [
    "tourism", "tourist", "travel", "heritage", "cultural", "hospitality",
    "السياحة", "السياحي", "سياحة", "تراث", "فندق",
]

def year_bucket(y):
    try:
        y = int(y)
    except Exception:
        return "unknown"
    if y < 1995:
        return "pre1995"
    if y > 2025:
        return "post2025"
    return f"{y // 5 * 5}-{y // 5 * 5 + 4}"

def lang_tier(r):
    """口径A/B 档位"""
    if r.get("pass_A_15") == "True":
        return "A(>=15%)"
    if r.get("pass_B_30") == "True":
        return "B(>30%)"
    return "none"

def judge(r):
    """元数据判定：返回 (类别, 依据)"""
    title = (r.get("title") or "").lower()
    venue = (r.get("venue") or "").lower()
    hits_title = [kw for kw in TITLE_TOURISM_KW if kw.lower() in title]
    hits_venue = [kw for kw in VENUE_TOURISM_KW if kw.lower() in venue]
    t_hits, v_hits = len(hits_title), len(hits_venue)
    if t_hits >= 2 or (t_hits >= 1 and v_hits >= 1):
        return "TOURISM_RELATED", f"题名命中{t_hits}个[{','.join(hits_title[:4])}];期刊命中{v_hits}个"
    if t_hits == 1:
        return "DOUBTFUL", f"题名仅命中1个关键词[{hits_title[0]}]，存疑"
    if v_hits >= 1:
        return "DOUBTFUL", f"期刊名含文旅词[{','.join(hits_venue[:3])}]但题名无命中，存疑"
    return "UNRELATED", "题名与期刊均无文旅关键词命中"

def main():
    random.seed(SEED)
    rows = list(csv.DictReader(open(SRC, encoding="utf-8-sig")))
    # 过滤口径A + 1995-2025
    pool = [r for r in rows if r.get("pass_A_15") == "True"
            and r.get("year", "").isdigit() and 1995 <= int(r["year"]) <= 2025]
    print(f"池: {len(pool)} 条（口径A·1995-2025）", flush=True)

    # 分层：来源库 x 年份桶
    strata = defaultdict(list)
    for r in pool:
        key = (r.get("source_db", "?"), year_bucket(r.get("year", "")))
        strata[key].append(r)
    print(f"层数: {len(strata)}", flush=True)

    # 每层按比例分配 200
    target = 200
    alloc = {}
    total_pool = len(pool)
    for key, items in sorted(strata.items(), key=lambda x: -len(x[1])):
        alloc[key] = max(1, round(len(items) / total_pool * target))
    # 修正总数
    while sum(alloc.values()) > target:
        # 去掉最小的一个配额（从最小层）
        k = min(alloc, key=lambda x: (alloc[x], x))
        alloc[k] -= 1
        if alloc[k] == 0:
            del alloc[k]
    while sum(alloc.values()) < target:
        k = max(alloc, key=lambda x: (alloc[x], x))
        alloc[k] += 1

    sampled = []
    for key, n in alloc.items():
        items = strata[key]
        picked = random.sample(items, min(n, len(items)))
        sampled.extend(picked)
    print(f"实际抽样: {len(sampled)} 条", flush=True)

    results = []
    for r in sampled:
        cat, basis = judge(r)
        results.append({
            "openalex_id": r.get("openalex_id", ""),
            "doaj_id": r.get("doaj_id", ""),
            "doi": r.get("doi", ""),
            "title": r.get("title", ""),
            "year": r.get("year", ""),
            "venue": r.get("venue", ""),
            "issn": r.get("issn", ""),
            "source_db": r.get("source_db", ""),
            "lang_tier": lang_tier(r),
            "ar_ratio": r.get("ar_ratio", ""),
            "judgment": cat,
            "basis": basis,
            "pdf_url": r.get("pdf_url", ""),
        })

    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        fieldnames = ["openalex_id", "doaj_id", "doi", "title", "year", "venue",
                      "issn", "source_db", "lang_tier", "ar_ratio", "judgment", "basis", "pdf_url"]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(results)

    print("=== 判定汇总（200条）===")
    for c in ["TOURISM_RELATED", "UNRELATED", "DOUBTFUL"]:
        print(f"  {c}: {sum(1 for r in results if r['judgment']==c)}")
    print("=== 按来源库 ===")
    print("  " + ", ".join(f"{k}:{v}" for k, v in Counter(r["source_db"] for r in results).most_common()))
    print("=== 按语言档位 ===")
    print("  " + ", ".join(f"{k}:{v}" for k, v in Counter(r["lang_tier"] for r in results).most_common()))
    print(f"输出: {OUT}")

if __name__ == "__main__":
    main()
