# -*- coding: utf-8 -*-
"""
任务A 第4层 v2：全文可用性检测（并发版）
8 线程并发检测 PDF 链接，全局 socket 超时防止 DNS 卡死。
"""
import csv, os, sys, time, urllib.request, ssl, socket
from concurrent.futures import ThreadPoolExecutor, as_completed

socket.setdefaulttimeout(8)

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "candidates_passA15.csv")
OUT = os.path.join(HERE, "candidates_passA15_pdfcheck.csv")

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE

def check_pdf(url, timeout=6):
    if not url:
        return "no_url"
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
            ct = (r.headers.get("Content-Type") or "").lower()
            if r.status == 200:
                if "pdf" in ct:
                    return "ok_pdf"
                return "ok_other:" + ct[:30]
            return f"http_{r.status}"
    except Exception as e:
        # HEAD 被拒则 GET 前 8KB
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "Range": "bytes=0-8191"})
            with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
                data = r.read(8192)
                if r.status in (200, 206):
                    if data[:4] == b"%PDF":
                        return "ok_pdf"
                    ct = (r.headers.get("Content-Type") or "").lower()
                    if "pdf" in ct:
                        return "ok_pdf"
                    return "ok_nopdf"
                return f"http_{r.status}"
        except Exception as e2:
            err = str(e2)
            if "404" in err or "403" in err or "HTTP Error 404" in err or "HTTP Error 403" in err:
                return "blocked"
            if "timed out" in err.lower() or "timeout" in err.lower():
                return "timeout"
            if "certificate" in err.lower():
                return "ssl_err"
            if "getaddrinfo" in err.lower() or "name or service" in err.lower():
                return "dns_err"
            return "err:" + type(e2).__name__

def main():
    if not os.path.exists(SRC):
        print(f"源文件不存在: {SRC}"); sys.exit(1)
    rows = list(csv.DictReader(open(SRC, encoding="utf-8-sig")))
    print(f"加载 {len(rows)} 条，8 线程并发检测", flush=True)
    stats = {}
    done = 0
    with ThreadPoolExecutor(max_workers=12) as ex:
        futs = {ex.submit(check_pdf, r.get("pdf_url", "")): i for i, r in enumerate(rows)}
        for fut in as_completed(futs):
            i = futs[fut]
            try:
                status = fut.result()
            except Exception:
                status = "err:worker"
            rows[i]["pdf_check"] = status
            stats[status] = stats.get(status, 0) + 1
            done += 1
            if done % 200 == 0:
                print(f"  进度 {done}/{len(rows)}", flush=True)
    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print("=== PDF 检测统计 ===")
    for k, v in sorted(stats.items(), key=lambda x: -x[1]):
        print(f"  {k}: {v}")
    print(f"输出: {OUT}")

if __name__ == "__main__":
    main()
