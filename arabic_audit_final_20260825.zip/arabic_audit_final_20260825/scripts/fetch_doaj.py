# -*- coding: utf-8 -*-
"""
DOAJ 阿语旅游/遗产期刊文章拉取（2026-08-20，任务A第1步）
策略（沿用 Manus 思路，但更全）：
1. 按 ISSN 锁定阿语旅游期刊（Manus 用的 3 个 + 补充扫描）
2. 阿语关键词全文搜索：سياحة / تراث / سياحية / تراثية
3. 英文关键词搜索：cultural tourism / heritage tourism（阿语期刊双语文章）
输出: CSV（DOAJ ID, DOI, 题名, 年份, 期刊, ISSN, 语言字段, PDF链接, 来源库=DOAJ）
"""
import json, time, urllib.request, urllib.parse, urllib.error, csv, os, re

BASE = "https://doaj.org/api/search/articles/"
HEADERS = {"Accept": "application/json", "User-Agent": "skwm-data-audit/1.0"}
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "candidates_doaj.csv")

# Manus 锁定的 3 本 ISSN + 我们补充的已知阿语旅游期刊
ISSN_TARGETS = [
    "2537-0510",  # Mansoura Faculty of Tourism and Hotels (EG) - Manus
    "2682-4329",  # Manus 第2本
    "2314-7024",  # Manus 第3本
]
KEYWORD_QUERIES = [
    "\u0633\u064a\u0627\u062d\u0629",     # سياحة tourism
    "\u062a\u0631\u0627\u062b",          # تراث heritage
    "\u0633\u064a\u0627\u062d\u064a\u0629", # سياحية touristic
    "\u062a\u0631\u0627\u062b\u064a\u0629", # تراثية heritage-related
    "cultural tourism",
    "heritage tourism",
    "travel",
]

def doaj_search(query, page, page_size=100):
    url = BASE + urllib.parse.quote(query) + f"?page={page}&pageSize={page_size}"
    req = urllib.request.Request(url, headers=HEADERS)
    # 走系统代理（Clash 1087）——Python 直连 DNS 解析失败，代理可通
    last_err = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code == 400:
                raise  # DOAJ 翻页超限，直接抛出让上层跳过
            last_err = e
            time.sleep(2 * (attempt + 1))
        except Exception as e:
            last_err = e
            time.sleep(2 * (attempt + 1))
    raise last_err

def norm_doi(d):
    if not d:
        return ""
    d = str(d).strip().lower()
    d = re.sub(r"^https?://(dx\.)?doi\.org/", "", d)
    return d

def extract_doaj_id(identifiers, issn_list):
    """DOAJ 没有独立 article id，用 DOI 或 ISSN+title 组合"""
    doi = ""
    for i in identifiers:
        if i.get("type") == "doi":
            doi = norm_doi(i.get("id", ""))
    return doi

def main():
    all_rows = []
    seen_keys = set()
    log_lines = []
    source_counts = {}

    # 1. ISSN 锁定期刊 → 全量文章
    for issn in ISSN_TARGETS:
        page = 1
        total = None
        got = 0
        fail_streak = 0
        while True:
            try:
                data = doaj_search(f'"{issn}"', page)
            except Exception as e:
                log_lines.append(f"[ISSN {issn}] page{page} ERROR: {e}")
                print(f"[ISSN {issn}] page{page} ERROR: {e}", flush=True)
                if "400" in str(e):
                    log_lines.append(f"[ISSN {issn}] 翻页超限(400)，截断")
                    print(f"[ISSN {issn}] 翻页超限，截断", flush=True)
                    break
                fail_streak += 1
                if fail_streak >= 5:
                    log_lines.append(f"[ISSN {issn}] 连续失败 5 次，跳过该期刊")
                    print(f"[ISSN {issn}] 连续失败 5 次，跳过", flush=True)
                    break
                time.sleep(3)
                continue
            fail_streak = 0
            if total is None:
                total = data.get("total", 0)
                log_lines.append(f"[ISSN {issn}] total={total}")
            results = data.get("results", [])
            if not results:
                break
            for r in results:
                b = r.get("bibjson", {})
                j = b.get("journal", {})
                issns = j.get("issns") or []
                ids = b.get("identifier") or []
                doi = norm_doi(next((i.get("id") for i in ids if i.get("type") == "doi"), ""))
                title = b.get("title") or ""
                key = doi or (title.strip().lower() + "|" + ",".join(sorted(issns)))
                if key in seen_keys:
                    continue
                seen_keys.add(key)
                year = b.get("year") or ""
                try:
                    year = int(year) if str(year).isdigit() else ""
                except Exception:
                    year = ""
                all_rows.append({
                    "doaj_id": doi or key[:60],
                    "doi": doi,
                    "title": title,
                    "year": year,
                    "venue": (j.get("title") or ""),
                    "issn": ",".join(issns),
                    "language": ",".join(j.get("language") or []),
                    "pdf_url": next((l.get("url") for l in (b.get("link") or []) if (l.get("type") or "").lower() in ("fulltext", "pdf")), ""),
                    "landing_url": next((l.get("url") for l in (b.get("link") or []) if (l.get("type") or "").lower() != "fulltext"), ""),
                    "source_db": "DOAJ",
                    "query": f"issn:{issn}",
                })
            got += len(results)
            if page * 100 >= total:
                break
            page += 1
            time.sleep(0.4)
        source_counts[f"issn:{issn}"] = got

    # 2. 关键词搜索（跳过 ISSN 已覆盖的）
    for kw in KEYWORD_QUERIES:
        page = 1
        total = None
        got = 0
        fail_streak = 0
        while True:
            try:
                data = doaj_search(kw, page)
            except Exception as e:
                log_lines.append(f"[KW '{kw}'] page{page} ERROR: {e}")
                print(f"[KW '{kw}'] page{page} ERROR: {e}", flush=True)
                if "400" in str(e):
                    log_lines.append(f"[KW '{kw}'] 翻页超限(400)，截断")
                    print(f"[KW '{kw}'] 翻页超限，截断", flush=True)
                    break
                fail_streak += 1
                if fail_streak >= 5:
                    log_lines.append(f"[KW '{kw}'] 连续失败 5 次，跳过")
                    print(f"[KW '{kw}'] 连续失败 5 次，跳过", flush=True)
                    break
                time.sleep(3)
                continue
            fail_streak = 0
            if total is None:
                total = data.get("total", 0)
                log_lines.append(f"[KW '{kw}'] total={total}")
            results = data.get("results", [])
            if not results:
                break
            added = 0
            for r in results:
                b = r.get("bibjson", {})
                j = b.get("journal", {})
                issns = j.get("issns") or []
                # 跳过已在 ISSN 锁定中的期刊
                if any(i in issns for i in ISSN_TARGETS):
                    continue
                ids = b.get("identifier") or []
                doi = norm_doi(next((i.get("id") for i in ids if i.get("type") == "doi"), ""))
                title = b.get("title") or ""
                key = doi or (title.strip().lower() + "|" + ",".join(sorted(issns)))
                if key in seen_keys:
                    continue
                seen_keys.add(key)
                year = b.get("year") or ""
                try:
                    year = int(year) if str(year).isdigit() else ""
                except Exception:
                    year = ""
                all_rows.append({
                    "doaj_id": doi or key[:60],
                    "doi": doi,
                    "title": title,
                    "year": year,
                    "venue": (j.get("title") or ""),
                    "issn": ",".join(issns),
                    "language": ",".join(j.get("language") or []),
                    "pdf_url": next((l.get("url") for l in (b.get("link") or []) if (l.get("type") or "").lower() in ("fulltext", "pdf")), ""),
                    "landing_url": next((l.get("url") for l in (b.get("link") or []) if (l.get("type") or "").lower() != "fulltext"), ""),
                    "source_db": "DOAJ",
                    "query": f"kw:{kw}",
                })
                added += 1
            got += added
            if page * 100 >= total or got == 0 or page >= 20:
                break
            page += 1
            time.sleep(0.4)
        source_counts[f"kw:{kw}"] = got

    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=[
            "doaj_id", "doi", "title", "year", "venue", "issn",
            "language", "pdf_url", "landing_url", "source_db", "query"])
        w.writeheader()
        w.writerows(all_rows)

    print("=== 拉取日志 ===")
    for l in log_lines:
        print(l)
    print("=== 各来源新增 ===")
    for k, v in source_counts.items():
        print(f"  {k}: {v}")
    print(f"=== 合计: {len(all_rows)} 条 ===")
    print(f"输出: {OUT}")

if __name__ == "__main__":
    main()
