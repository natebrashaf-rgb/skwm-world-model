# -*- coding: utf-8 -*-
"""
pool_27_cd.csv 导出脚本（2026-08-25，A/B 终版打包）
=====================================================
来源：B1 主表（最新版 rail_deploy/data/B1_文献主表.json，8-22 更新，
      12233 条，与 Neo4j Paper 12233 一致）中 language=="ar" 的 27 条。
      —— 不用 _group_code 旧版（12155 条、ar 仅 14 条，8-17 后未更新）
输出列：
  idx             1-27 序号
  title           题名（主表原文，阿语/中阿双语）
  year            年份（无则为空）
  authors         作者（逗号分隔）
  venue           期刊/来源
  doi             DOI（部分条目无）
  _source         来源文件夹
  language        主表语言字段（全部 ar）
  keywords        关键词（主表原样，list）
  has_pdf         主表 has_pdf 字段（True/False）
  pdf_texts_match 阿语文本库匹配状态：matched=pdf_texts.json 中有该篇全文 / not_matched=无
  pdf_texts_key   匹配到的 pdf_texts.json 键名（未匹配为空）

匹配算法（可复现，pdf_texts.json 为 E:\大挑\rail_deploy\data\pdf_texts.json，6063 键）：
  1) DOI 直配：键名 = 规范化 DOI（去 / 与 .）
  2) 阿语题名子串：题名规范化（归一 hamza、去标点）前 40 字符出现在键名规范化中，或反向
  3) 英文键特例（题名为阿语、PDF 文件名为英文，已人工核对 value 首屏标题）：
     10.58205_fber.v3i1.1462  -> #15 沙漠旅游（键名为 DOI）
     10.47832_2717-8293.16.26 -> #16 绿洲水旅游（键名为 DOI）
     Extra_Sustainable Investment In Architectural Heritage -> #17（value 首屏=主表题名）
     Extra_Tabe'a III nature-culture linkages -> #18（value 首屏=主表题名）
     Extra_Embroidery with Smart Threads of some Saudi -> #19（value 内含 التطريز/Embroidery）
"""
import json, os, re, unicodedata, csv

MASTER = r"E:\大挑\rail_deploy\data\B1_文献主表.json"
PDFTEXTS = r"E:\大挑\rail_deploy\data\pdf_texts.json"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "screening", "pool_27_cd.csv")

def norm(s):
    s = unicodedata.normalize("NFKC", str(s or ""))
    s = s.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ى", "ي")
    s = re.sub(r"[\W_]+", "", s).lower()
    return s

def key_core(k):
    m = re.sub(r"^(Extra|Arab|Ara|Gen|Tour)_", "", k)
    m = re.sub(r"^\d+_", "", m)
    return m

def main():
    master = json.load(open(MASTER, encoding="utf-8-sig"))
    pt = json.load(open(PDFTEXTS, encoding="utf-8-sig"))
    ks = list(pt.keys())

    ar = [r for r in master if r.get("language") == "ar"]
    assert len(ar) == 27, f"主表 language=ar 应为 27 条，实际 {len(ar)}"

    # 预处理键
    knorm = {k: norm(key_core(k)) for k in ks}
    # 英文键但 value 阿语多（>=200 阿语字符）的候选
    arval_keys = []
    for k in ks:
        if re.search(r"[\u0600-\u06FF]", k):
            continue
        v = pt[k]
        if isinstance(v, str) and len(re.findall(r"[\u0600-\u06FF]", v)) >= 200:
            arval_keys.append(k)

    # 人工核对的英文键特例（value 首屏含主表题名）
    SPECIAL = {
        "الاستثمار المستدام في مباني التراث": "Extra_Sustainable Investment In Architectural",
        "الروابط بين الطبيعة والثقافة": "Extra_Tabe'a III _ nature–culture linkages",
        "التطريز بالخيوط الذكية": "Extra_Embroidery with Smart Threads of some Sa",
    }

    rows = []
    for i, r in enumerate(ar, 1):
        t = r.get("title") or ""
        doi = (r.get("doi") or "").strip()
        tn = norm(t)
        hit = ""; how = ""
        # 1) DOI 键直配
        if doi:
            dn = norm(doi)
            for k in ks:
                if norm(k) == dn or norm(key_core(k)) == dn:
                    hit = k; how = "doi_key"; break
        # 2) 阿语题名子串
        if not hit:
            for k, kn in knorm.items():
                if len(tn) >= 12 and tn[:40] in kn:
                    hit = k; how = "ar_substr"; break
        if not hit:
            for k, kn in knorm.items():
                if len(kn) >= 12 and kn in tn:
                    hit = k; how = "ar_contain"; break
        # 3) 英文特例
        if not hit:
            for frag, pref in SPECIAL.items():
                if frag in (t or ""):
                    for k in arval_keys:
                        if k.startswith(pref):
                            hit = k; how = "special_en"; break
                    if hit:
                        break
        rows.append({
            "idx": i, "title": t, "year": r.get("year") or "",
            "authors": r.get("authors") or "", "venue": r.get("venue") or "",
            "doi": doi, "_source": r.get("_source") or "",
            "language": r.get("language") or "", "keywords": json.dumps(r.get("keywords") or [], ensure_ascii=False),
            "has_pdf": r.get("has_pdf"), "pdf_texts_match": "matched" if hit else "not_matched",
            "pdf_texts_key": hit, "match_method": how,
        })

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    n_m = sum(1 for x in rows if x["pdf_texts_match"] == "matched")
    print(f"pool_27_cd.csv 已写出: {OUT}")
    print(f"共 {len(rows)} 条，阿语文本库匹配 {n_m} 条，未匹配 {len(rows) - n_m} 条")
    for x in rows:
        print(f"  #{x['idx']:>2} {x['pdf_texts_match']:<11} {x['match_method']:<12} {str(x['title'])[:42]} -> {str(x['pdf_texts_key'])[:50]}")

if __name__ == "__main__":
    main()
