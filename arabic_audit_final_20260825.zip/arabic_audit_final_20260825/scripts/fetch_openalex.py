# -*- coding: utf-8 -*-
"""
OpenAlex 阿语文旅文献拉取（2026-08-20，任务A第1步）
范围: language:ar, 1995-01-01 ~ 2025-12-31
主题: tourism / heritage / travel / hospitality / 阿语 سياحة / تراث
输出: CSV（OpenAlex ID, DOI, 题名, 年份, 期刊, ISSN, 语言, PDF链接, 来源库=OpenAlex）
全量翻页: cursor 分页，per-page=200
"""
import json, time, urllib.request, urllib.parse, csv, sys, os, re

BASE = "https://api.openalex.org/works"
MAILTO = "nxy@example.com"  # polite pool
QUERIES = {
    "tourism":      "tourism",
    "heritage":     "heritage",
    "travel":       "travel",
    "hospitality":  "hospitality",
    "siyaha_ar":    "\u0633\u064a\u0627\u062d\u0629",      # سياحة 旅游(阿语)
    "turath_ar":    "\u062a\u0631\u0627\u062b",           # تراث 遗产(阿语)
}

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "candidates_openalex.csv")

def fetch_cursor(filter_str, cursor="*"):
    params = {
        "filter": filter_str,
        "per-page": "200",
        "cursor": cursor,
        "mailto": MAILTO,
        "select": "id,doi,title,publication_year,primary_location,best_oa_location,language",
    }
    url = BASE + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "skwm-data-audit/1.0 (academic research)"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())

def norm_doi(d):
    if not d:
        return ""
    d = str(d).strip().lower()
    d = re.sub(r"^https?://(dx\.)?doi\.org/", "", d)
    return d

def main():
    all_rows = []
    seen_ids = set()
    total_api = 0
    log_lines = []
    for qname, qterm in QUERIES.items():
        f = f"language:ar,from_publication_date:1995-01-01,to_publication_date:2025-12-31,title_and_abstract.search:{urllib.parse.quote(qterm)}"
        cursor = "*"
        page = 0
        q_count = 0
        while True:
            page += 1
            try:
                data = fetch_cursor(f, cursor)
            except Exception as e:
                log_lines.append(f"[{qname}] page{page} ERROR: {e}")
                time.sleep(3)
                continue
            meta = data.get("meta", {})
            results = data.get("results", [])
            if page == 1:
                log_lines.append(f"[{qname}] '{qterm}' meta.count={meta.get('count')}")
            if not results:
                break
            for r in results:
                wid = (r.get("id") or "").replace("https://openalex.org/", "")
                if wid in seen_ids:
                    continue
                seen_ids.add(wid)
                loc = r.get("primary_location") or {}
                best = r.get("best_oa_location") or {}
                src = loc.get("source") or {}
                pdf = best.get("pdf_url") or loc.get("pdf_url") or ""
                all_rows.append({
                    "openalex_id": wid,
                    "doi": norm_doi(r.get("doi")),
                    "title": r.get("title") or "",
                    "year": r.get("publication_year") or "",
                    "venue": (src.get("display_name") or ""),
                    "issn": ",".join(src.get("issn") or []) if src else "",
                    "language": r.get("language") or "",
                    "pdf_url": pdf or "",
                    "landing_url": (loc.get("landing_page_url") or ""),
                    "source_db": "OpenAlex",
                    "query": qname,
                })
            q_count += len(results)
            total_api += len(results)
            cursor = meta.get("next_cursor")
            if not cursor:
                break
            time.sleep(0.3)  # rate limit
        log_lines.append(f"[{qname}] 实际返回 {q_count}（去重后累计 {len(all_rows)}）")

    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=[
            "openalex_id", "doi", "title", "year", "venue", "issn",
            "language", "pdf_url", "landing_url", "source_db", "query"])
        w.writeheader()
        w.writerows(all_rows)

    print("=== 拉取日志 ===")
    for l in log_lines:
        print(l)
    print(f"=== 合计: API返回 {total_api} 条 / 去重后 {len(all_rows)} 条 ===")
    print(f"输出: {OUT}")

if __name__ == "__main__":
    main()
