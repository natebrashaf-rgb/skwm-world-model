# -*- coding: utf-8 -*-
"""
重试 PDF 检测：只处理之前 timeout / err 的记录，20 秒超时，8 线程。
先抽样 100 条验证命中率，再全量。
"""
import csv, os, sys, time, urllib.request, ssl, socket, random
from concurrent.futures import ThreadPoolExecutor, as_completed

socket.setdefaulttimeout(25)
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "candidates_passA15_pdfcheck.csv")
OUT = os.path.join(HERE, "candidates_passA15_pdfcheck_v2.csv")

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE

def check_pdf(url, timeout=20):
    if not url:
        return "no_url"
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
            ct = (r.headers.get("Content-Type") or "").lower()
            if r.status == 200:
                if "pdf" in ct:
                    return "ok_pdf"
                return "ok_other:" + ct[:30]
            return f"http_{r.status}"
    except Exception as e:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "Range": "bytes=0-8191"})
            with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
                data = r.read(8192)
                if r.status in (200, 206):
                    if data[:4] == b"%PDF":
                        return "ok_pdf"
                    ct = (r.headers.get("Content-Type") or "").lower()
                    if "pdf" in ct:
                        return "ok_pdf"
                    return "ok_nopdf"
                return f"http_{r.status}"
        except Exception as e2:
            err = str(e2)
            if "404" in err or "403" in err or "HTTP Error 404" in err or "HTTP Error 403" in err:
                return "blocked"
            if "timed out" in err.lower() or "timeout" in err.lower():
                return "timeout2"
            return "err:" + type(e2).__name__

def main():
    if not os.path.exists(SRC):
        print("源不存在"); sys.exit(1)
    rows = list(csv.DictReader(open(SRC, encoding="utf-8-sig")))
    # 找出需要重试的：timeout 或 err 开头或 blocked
    retry_idx = [i for i, r in enumerate(rows) if r.get("pdf_check", "") in ("timeout",) or r.get("pdf_check", "").startswith("err:")]
    print(f"总 {len(rows)}，需重试 {len(retry_idx)}", flush=True)

    # 抽样 100 验证
    sample = random.sample(retry_idx, min(100, len(retry_idx)))
    sample_stats = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(check_pdf, rows[i].get("pdf_url", "")): i for i in sample}
        for fut in as_completed(futs):
            i = futs[fut]
            try:
                s = fut.result()
            except Exception:
                s = "err:worker"
            sample_stats[s] = sample_stats.get(s, 0) + 1
    print("=== 抽样 100 条重试结果 ===")
    for k, v in sorted(sample_stats.items(), key=lambda x: -x[1]):
        print(f"  {k}: {v}")

    # 全量重试（含抽样，覆盖写回）
    stats = {}
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(check_pdf, rows[i].get("pdf_url", "")): i for i in retry_idx}
        done = 0
        for fut in as_completed(futs):
            i = futs[fut]
            try:
                s = fut.result()
            except Exception:
                s = "err:worker"
            rows[i]["pdf_check"] = s
            stats[s] = stats.get(s, 0) + 1
            done += 1
            if done % 300 == 0:
                print(f"  重试进度 {done}/{len(retry_idx)}", flush=True)

    with open(OUT, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print("=== 重试后统计（仅重试部分） ===")
    for k, v in sorted(stats.items(), key=lambda x: -x[1]):
        print(f"  {k}: {v}")
    print(f"输出: {OUT}")

if __name__ == "__main__":
    main()
