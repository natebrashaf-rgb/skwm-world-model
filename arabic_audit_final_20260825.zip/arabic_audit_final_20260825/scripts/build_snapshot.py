# -*- coding: utf-8 -*-
"""
图库聚合层快照（2026-08-21）
============================
用途：给 Manus 页面/连 GitHub 读图用。仅聚合层，不含全文PDF、不含作者个人字段。

口径（与 rebuild_neo4j.py 完全一致，保证与 Neo4j 图库数字对得上）:
  - paper_topics[pid] = set(terms)（同一篇内主题词去重）
  - year_topic[(year, topic)] += 1 仅当 year_valid (0 < year <= 2026)
  - Paper 节点 id = str(doi or title)[:200]
  - Domain = matched 论文 domains ∪ {非文旅}
  - 校验: sum(len(paper_topics)) == HAS_TOPIC 审计值 29704

输出（E:\\大挑\\产出\\交接_20260821\\）:
  graph_snapshot_20260821.json   主快照（meta + 节点/边计数 + 节点清单 + 主题×年度热度）
  topic_year_heat.csv            主题×年度热度轻量表
"""
import json, os, csv
from collections import Counter, defaultdict

DATA = r"E:\大挑\rail_deploy\data"
OUT = r"E:\大挑\产出\交接_20260821"

def to_int(x):
    try:
        return int(float(x))
    except (ValueError, TypeError):
        return 0

# 1. 加载
b1 = json.load(open(os.path.join(DATA, "B1_文献主表.json"), encoding="utf-8"))
ta = json.load(open(os.path.join(DATA, "topic_assignments.json"), encoding="utf-8"))
audit = json.load(open(os.path.join(DATA, "graph_audit_20260819.json"), encoding="utf-8"))
print(f"加载: B1 {len(b1)} | topic_assignments {len(ta)}")

# 2. 复刻 rebuild 聚合
paper_topics = {}     # pid -> set(terms)
paper_domains = {}    # pid -> set(domains)
non_tourism = set()   # pid 集合
for pid, v in ta.items():
    if v.get("matched"):
        paper_topics[pid] = set(v.get("terms", []))
        paper_domains[pid] = set(v.get("domains", []))
    elif v.get("non_tourism"):
        non_tourism.add(pid)

year_topic = Counter()   # (year, topic) -> count
for p in b1:
    pid = str(p.get("doi") or p.get("title"))[:200]
    year = to_int(p.get("year"))
    year_valid = 0 < year <= 2026
    for t in paper_topics.get(pid, set()):
        if year_valid:
            year_topic[(year, t)] += 1

n_has_topic = sum(len(t) for t in paper_topics.values())
n_year_valid = sum(year_topic.values())
print(f"HAS_TOPIC 复刻: {n_has_topic} (审计 29704) | year_topic 有效和: {n_year_valid}")

# 3. 节点清单
paper_nodes = []
seen_pid = set()
for p in b1:
    pid = str(p.get("doi") or p.get("title"))[:200]
    if pid in seen_pid:
        continue
    seen_pid.add(pid)
    paper_nodes.append({"id": pid, "title": p.get("title", "")})
print("Paper 节点:", len(paper_nodes))

topic_names = sorted(set().union(*[paper_topics[pid] for pid in paper_topics]))
print("Topic 节点:", len(topic_names), "(审计 1173)")

years = sorted({to_int(p.get("year")) for p in b1 if 0 < to_int(p.get("year")) <= 2026})
print("Year 节点:", len(years), "(审计 84)")

domains = sorted(set().union(*[paper_domains[pid] for pid in paper_domains]) | {"非文旅"})
print("Domain 节点:", len(domains), "(审计 27)")

# 4. 主题×年度热度
heat = [{"topic": t, "year": y, "count": c} for (y, t), c in year_topic.items()]
heat.sort(key=lambda r: (-r["count"], r["year"], r["topic"]))
print("topic×year 热度行数:", len(heat), "| 总计数:", sum(r["count"] for r in heat))

# 5. 写 JSON
snap = {
    "meta": {
        "file": "graph_snapshot_20260821.json",
        "generated_at": "2026-08-21",
        "generated_by": "build_snapshot.py（复刻 rebuild_neo4j.py 聚合口径）",
        "source": "本地 Neo4j 重建图库（2026-08-19 重建，graph_audit_20260819.json 校验）",
        "purpose": "给 Manus 页面/连 GitHub 读图用；仅聚合层",
        "rules": [
            "不含全文 PDF/正文文本",
            "不含作者个人字段（Author 节点仅计数，不导明细）",
            "year<=0 或 >2026 的 Paper 保留节点但无 Year 关系/PUBLISHED_IN_YEAR（rebuild 口径）",
            "同一篇内重复主题词已去重（set），与 HAS_TOPIC 关系数一致",
        ],
        "counts_verify": {
            "HAS_TOPIC_审计": audit["rel_by_type"]["HAS_TOPIC"],
            "HAS_TOPIC_复刻": n_has_topic,
            "year_topic_有效和": n_year_valid,
            "year_topic_无效年份边": n_has_topic - n_year_valid,
            "Topic_审计": audit["node_by_label"]["Topic"],
            "Topic_复刻": len(topic_names),
            "Domain_审计": audit["node_by_label"]["Domain"],
            "Domain_复刻": len(domains),
            "Year_审计": audit["node_by_label"]["Year"],
            "Year_复刻": len(years),
        },
    },
    "node_counts": audit["node_by_label"],
    "node_total": audit["node_total"],
    "edge_counts": audit["rel_by_type"],
    "edge_total": audit["rel_total"],
    "isolated_nodes": audit["isolated_nodes"],
    "nodes": {
        "Paper": paper_nodes,
        "Topic": [{"name": t} for t in topic_names],
        "Year": [{"year": y} for y in years],
        "Domain": [{"name": d} for d in domains],
        "Author": {"count": audit["node_by_label"]["Author"], "note": "个人字段不导出"},
        "Venue": {"count": audit["node_by_label"]["Venue"], "note": "期刊名，聚合层仅计数"},
    },
    "topic_year_heat": heat,
}

p_json = os.path.join(OUT, "graph_snapshot_20260821.json")
with open(p_json, "w", encoding="utf-8") as f:
    json.dump(snap, f, ensure_ascii=False, indent=1)
print("写入:", p_json, os.path.getsize(p_json), "bytes")

# 6. 写 CSV（轻量热力表）
p_csv = os.path.join(OUT, "topic_year_heat.csv")
with open(p_csv, "w", newline="", encoding="utf-8-sig") as f:
    w = csv.DictWriter(f, fieldnames=["topic", "year", "count"])
    w.writeheader()
    w.writerows(heat)
print("写入:", p_csv, len(heat), "行")
