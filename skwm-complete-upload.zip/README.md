# SKWM 智能学科服务平台 — 完整版

> 科学知识世界模型 (SKWM) 驱动的高校图书馆智能学科服务
> 以北京第二外国语学院中阿文旅知识服务平台为例

---

## 📋 项目结构

```
skwm-complete/
├── app/                          ← Next.js 前端 (8个页面)
│   ├── dashboard/                ← 工作台
│   ├── rag-advisor/              ← 智能问答 (GraphRAG)
│   ├── knowledge-graph/          ← 知识图谱
│   ├── scientometrics/           ← 科学计量
│   ├── scenarios/                ← 应用场景
│   ├── literature/               ← 文献管理
│   ├── reports/                  ← 报告中心
│   └── settings/                 ← 系统设置
│
├── backend/                      ← Python 后端
│   ├── api.py                   ← FastAPI 服务
│   ├── skwm_aligned_v4.py       ← SKWM 核心控制器
│   ├── skwm_closed_loop.py      ← 闭环规划 (外壳)
│   ├── skwm_world_model.py      ← RSSM 预测器 (内核)
│   ├── knowledge_graph.py       ← 知识图谱引擎
│   ├── graph_rag.py             ← GraphRAG
│   ├── vector_store.py          ← 向量存储
│   ├── world_model/             ← 世界模型模块
│   │   ├── world_model.py
│   │   ├── state_encoder.py
│   │   ├── causal_interface.py
│   │   ├── aligner.py
│   │   └── evaluation.py
│   ├── report_generator.py      ← 报告生成器
│   ├── feishu_bot.py            ← 飞书机器人
│   ├── obsidian_sync.py         ← Obsidian同步
│   └── requirements.txt         ← Python依赖
│
├── lib/api.ts                   ← 前端API桥接
├── next.config.js               ← API代理配置
├── vercel.json                  ← Vercel 部署配置
└── package.json                 ← 前端依赖
```

---

## 🚀 部署到 Vercel (最简单)

### 方式 1：只部署前端

1. 打开 https://vercel.com → New Project
2. Import `D:\vault\sheer\skwm-complete` (或上传到 GitHub 再导入)
3. 保持默认设置 (Framework = Next.js)
4. Deploy → 几分钟后得到 `https://xxx.vercel.app`

> 前端 8 个页面全部静态生成，无需后端也能展示 UI。
> 数据目前是模拟数据，可在 `app/*/page.tsx` 中替换为真实 API 调用。

### 方式 2：前端 + Python 后端

**后端部署** (Railway / 任意 VPS)：
```bash
cd backend
pip install -r requirements.txt
uvicorn api:app --host 0.0.0.0 --port 8000
```

**前端连接后端**：
在 Vercel 项目 Settings → Environment Variables 添加：
```
NEXT_PUBLIC_API_BASE=https://your-backend-url.com
```

---

## 🧪 本地运行

```bash
# 前端
cd skwm-complete
npm install
npx next dev       # http://localhost:3000

# 后端 (另一个终端)
cd skwm-complete/backend
pip install -r requirements.txt
uvicorn api:app --reload --port 8000
# http://localhost:8000/docs
```

---

## 🧠 世界模型内核 (RSSM)

```bash
cd backend
python skwm_world_model.py       # 训练+预测演示
python skwm_closed_loop.py       # 闭环规划演示
```

---

## 📚 文献资料库

768 篇中阿文旅相关 PDF，位于：
`D:\vault\sheer\世界模型\📚_文献资料库\`

---
