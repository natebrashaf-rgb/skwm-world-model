# README_reproducibility.md

## 这是什么包

阿拉伯文献（阿语文旅主题）筛选审计 A/B 终版交付包。包含：两个 API 原始候选表、
四层漏斗各阶段筛选结果、全部生成脚本、API 查询日志、121 条全文名单与下载状态、
数据字典和本复现说明。供评审复核与复跑使用。

打包时间：2026-08-25
数据来源：2026-08-20 ~ 08-21 拉取与筛选（未重新跑 API、未修改 B1 主表）

## 目录结构

```
arabic_audit_final_20260825/
├── raw/                     API 原始候选
│   ├── candidates_openalex.csv   3397 条（OpenAlex，6 查询词并集）
│   └── candidates_doaj.csv       4109 条（DOAJ，3 ISSN + 7 关键词）
├── screening/               漏斗各层筛选结果
│   ├── candidates_merged_deduped.csv   7209 条（合并+去重）
│   ├── candidates_passA15_pdfcheck.csv 3457 条（口径A + PDF 检测）
│   ├── screening_final.csv            3457 条（终版主表，= arabic_master_20260821.csv）
│   ├── pool_121_fulltext.csv          121 条（全文池，pdf_check=ok_pdf）
│   ├── pool_90_cases.csv               90 条（案例池）
│   ├── pool_27_cd.csv                 27 条（B1 主表 language=ar，含 has_pdf 与文本库匹配）
│   ├── dedup_report.txt               三层去重报告（DOI 撞 52 / ID 撞 0 / 题名撞 15）
│   └── funnel_report.txt              四层漏斗报告（L1-L4 统计明细）
├── scripts/                全部生成脚本（可复跑）
├── logs/                    API 查询与核验日志（日期/分页/失败重试）
├── pdf_manifest.csv         121 条全文名单 + 下载状态
├── data_dictionary.md       每个文件每列含义
└── README_reproducibility.md
```

## 四层漏斗对账表（核心数字）

| 层 | 说明 | 数字 | 对应文件 |
|----|------|------|---------|
| L1 | API 原始候选 | 7506 = OpenAlex 3397 + DOAJ 4109 | raw/ 两个 csv |
| L1.5 | 合并 + 内部去重 + 与 B1 主表三层去重 | 7209（内部去重 7276 → 撞 DOI 52 → 撞题名 15） | screening/candidates_merged_deduped.csv |
| L2 | 题名语言复核（口径A/B） | 口径A（阿语≥15% 且波斯≤15%）3457 → 1995-2025: 3416；口径B（阿语>30%）3364 → 1995-2025: 3323 | screening/candidates_passA15_pdfcheck.csv |
| L3 | 全文可得（PDF 实测能下） | 121（1995-2025 全部；OpenAlex 114 / 双库 1 / DOAJ 6） | screening/pool_121_fulltext.csv、pdf_manifest.csv |
| L4 | 案例池 / 入模型 | 案例池 90（AR_PURE 61 + QUAL_CASE 24 + AR_EN_BILING 5）；入模型 61（纯阿语正文+文旅+全文） | screening/pool_90_cases.csv |
| 附 | B1 主表阿语文献 | 27 条（language=ar；17 条在阿语文本库有全文） | screening/pool_27_cd.csv |

对应漏斗报告：scripts/funnel_report.py 生成 funnel_report.txt（L1-L4 全部统计明细）。

## 怎么复跑（按顺序执行，命令与预期数字）

前置：Windows + Python 3.11+；需要联网（OpenAlex/DOAJ API）；B1 主表在
`E:\大挑\rail_deploy\data\B1_文献主表.json`（12233 条最新版）；文本库
`E:\大挑\rail_deploy\data\pdf_texts.json`（6063 篇全文）。

```
1. python scripts/fetch_openalex.py      -> raw/candidates_openalex.csv       预期 3397 条
2. python scripts/fetch_doaj.py          -> raw/candidates_doaj.csv           预期 4109 条
3. python scripts/dedup_and_lang.py      -> candidates_merged_deduped.csv     预期 7209 条
                                           candidates_passA15.csv             预期 3457 条
                                           dedup_report.txt / language_report.txt
4. python scripts/check_pdf.py           -> candidates_passA15_pdfcheck.csv   预期 3457 条（pdf_check=ok_pdf 121）
5. python scripts/check_pdf_retry.py     -> 抽样 50 条验证 timeout=网络阻断（可跳过，验证用）
6. python scripts/B1_fulltext_verify.py  -> B1_fulltext_verification.csv      预期 121 条
7. python scripts/dedup_cases.py         -> qual_case_dedup.csv               预期 90 条
8. python scripts/fetch_authors.py       -> qual_case_authors.csv（作者补充，可选）
9. python scripts/build_master.py        -> screening_final.csv               预期 3457 条
                                           arabic_model_inclusion.csv         预期 121 条
                                           arabic_case_pool_90.csv            预期 90 条
10. python scripts/build_snapshot.py     -> graph_snapshot / topic_year_heat（图库聚合层快照）
11. python scripts/build_pool27.py       -> screening/pool_27_cd.csv          预期 27 条（17 matched）
12. python scripts/funnel_report.py      -> funnel_report.txt（对账表数字复核）
```

注：build_master.py 与 build_pool27.py 的输入路径为源目录绝对路径，复跑时如路径变化
需同步修改脚本内路径常量。fetch 类脚本重跑会重新请求 API 且覆盖 raw 表（本包文件即
2026-08-20 运行的产物，未重跑）。

## 复跑注意事项（跨机器）

scripts 内硬编码的 E:\ 绝对路径（如 E:\大挑\rail_deploy\data\B1_文献主表.json、
E:\大挑\产出\manus_reference_20260820\ 等）在他人机器复跑时需自行替换为本地实际路径。


## 关键口径说明

1. **口径A / 口径B**：题名阿语占比。A = 阿语≥15% 且波斯专属≤15%；B = 阿语>30%。两者都与
   B1 主表（12177 基线，8-20 时点）做过三层去重，均为相对 B1 的真实增量。
2. **121 条全文池**：pdf_check=ok_pdf（真实下到 PDF）。不可用明细：timeout 1850（埃及
   ekb.eg 网络阻断，抽样验证）/ 无链接 1085 / HTML 页 192 / 其他错误 209。
3. **六类判定**（B1_fulltext_verify.py）：AR_PURE（纯阿语正文）/ QUAL_CASE（定性案例）/
   AR_EN_BILING（阿英双语）/ LANG_MISJUDG（语言误判，含波斯/土耳其标题）/ NOT_TOURISM（非文旅）/
   QUANT_ONLY（仅数量证据）。
4. **include_in_model = 1（61 条）**：纯阿语正文（正文阿语≥60% 且英文<20% 且波斯=0）＋文旅主题词
   命中≥1 ＋ 全文可得 三条全满足。防止波斯语/土耳其语误判混入模型。
5. **pool_27_cd.csv 口径**：B1 主表（最新版 12233 条，8-22 更新，与 Neo4j Paper 12233 一致）中
   language=ar 的 27 条。注意：_group_code 目录下的旧版主表（12155 条）language=ar 仅 14 条，
   是 8-17 后未更新的旧版，故取 rail_deploy 最新版。has_pdf 取自主表字段；阿语文本库匹配 =
   该篇全文是否存在于 pdf_texts.json（6063 篇），匹配方法见 build_pool27.py（DOI 键直配 /
   阿语题名子串 / 英文键特例，特例已人工核对 value 首屏标题）。

## 本次未查/未覆盖的部分（诚实清单）

1. **OpenAlex 逐页 API 日志未落盘**：fetch_openalex.py 当时只打印控制台，原始逐页输出
   未保存，无法还原；logs/openalex_fetch_log.txt 如实说明并提供脚本逻辑与留存统计
   （详见该文件）。DOAJ 日志有完整落盘（logs/doaj_fetch_log.txt）。
2. **B1 主表版本差异**：pool_27 采用 rail_deploy 最新版（12233 条）而非 _group_code 旧版
   （12155 条）——差异为 8-21/8-22 补录 56 篇 + 语言字段修订所致，两版 language=ar 均为 27 条。
3. **121 全文核验为 8-20 产物**，本包未重跑全文核验，直接沿用 B1_fulltext_verification.csv。
4. **90 案例池弱组#2（伊斯兰金融 2 篇）**建议人工确认是否保留为文旅案例（前次已标）。
5. **6 条无作者案例**（5 条沙特 JAP-KSU 期刊 + 1 条纯 DOAJ）OpenAlex 查不到，待人工。
6. **候选层 3295 条**只做了题名语言复核，未逐篇核正文（正文核验只做在 121 条上）。
7. **pool_27 中 10 条未匹配阿语文本库**（教学/书法/伊斯兰文化类，has_pdf 全 False）：
   主表登记有这些条目但无全文文本支撑，属主表既有状态，本包未改动主表。
